using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Interact with query parameters or the body of the request.
$name = $Request.Query.Name
if (-not $name) {
    $name = $Request.Body.Name
}

$body = "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."

if ($name) {
    $body = "Hello, $name. This HTTP triggered function executed successfully."
}
$requestedByUserId = ([Guid]::NewGuid().Guid).ToString()
$csvDevices = $Request.Body.CsvDeviceList
Write-Host $csvDevices
If(-not $csvDevices)
{
    $requestedByUserId = $Request.Body.RequestedByUserId #"0ecba90d-7605-453c-971e-bf80f6537e56"  #$Request.Body.RequestedBy
    $deviceId = $Request.Body.MACAddress #"01:01:02:03:04"
    $description = $Request.Body.Description #"this is a polycom device"
    $idType = "MACAddress"
    $upn = $Request.Body.UPN #"cap1@MODERNCOMMS996974.onmicrosoft.com"
    $location = $Request.Body.Location #"USA"
    $description = $Request.Body.Description #"Some description"

    $newDevice = @{}
    $newDevice.Add("MacAddress", $deviceId)
    $newDevice.Add("ID Type", $idType)
    $newDevice.Add("Location", $location)
    $newDevice.Add("UPN", $upn)
    $newDevice.Add("Description", $description)
    $newDeviceCSV = $newDevice | ConvertTo-Csv
    $newDeviceBlobContent = $newDeviceCSV -join "`r`n" | out-string
}
else
{
    $newDeviceBlobContent = $csvDevices -join "`r`n" | out-string
}


# TBD: Add RG name and storage name to app settings
$StorageAccount = Get-AzStorageAccount -ResourceGroupName 'tdme-rg' -Name 'tdmestorage'
$ctx = $StorageAccount.Context

# TBD: Add to appsettings
$templateblobname = "SampleForProvisioning.csv"
$container = "devicesmanifest"
$newDeviceBlobName = $requestedByUserId +"_"+ [Guid]::NewGuid().Guid +"_NewDeviceRequest.csv"

# Get template blob - which is a sample blob file pre-created in the blob storage
$tempblob = Get-AzStorageBlob -Context $ctx -Container $container -Blob $templateblobname
# Create a new blob file by making a copy of the template file
$tempblob | Start-AzStorageBlobCopy -Context $ctx -DestContext $ctx -DestContainer $container -DestBlob $newDeviceBlobName
$newblob = Get-AzStorageBlob -Context $ctx -Container $container -Blob $newDeviceBlobName
# Add the new device request to the new blob file
$newblob.ICloudBlob.UploadText($newDeviceBlobContent)

<#
# Add the new device request to the azure table
$tableName = "DevicesInfo"
$storageTable = Get-AzStorageTable –Name $tableName –Context $ctx
$cloudTable = $storageTable.CloudTable
Add-AzTableRow -table $cloudTable -partitionKey $requestedByUserId -rowKey ([Guid]::NewGuid().Guid) -property @{"ID"=$deviceId;"IDType"=$idType;"Location"=$location;"Description"=$description;"BlobFileName"=$newDeviceBlobName;"OTP"=1234;"OTPExpiry"="2023-02-10T23=30=00Z";"ProvisionStatus"="Pending";"RemoteSignStatus"="Pending";"UPN"=$upn}
#>

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $body
})
