# Input bindings are passed in via param block.
param([byte[]] $InputBlob, $TriggerMetadata)

# Write out the blob name and size to the information log.
Write-Host "PowerShell Blob trigger function Processed blob! Name: $($TriggerMetadata.Name) Size: $($InputBlob.Length) bytes"

$csvString = [System.Text.Encoding]::ASCII.GetString($InputBlob)
Write-Host $csvString.GetType()

#$csvObj = $csvString | ConvertTo-Csv
$csvObj = $csvString | ConvertFrom-Csv -Delim ','
Write-Host $csvObj.GetType()



# TODO: Invoke TDME script here to get OTP for the devices
$TDMExtensions = ".\Modules\TeamsDeviceManagementExtensions"
Import-Module $TDMExtensions

$TDMESvcAccountId  = $ENV:TDMESvcAccntUserId 
$TDMESvcAccountPwd = $ENV:TDMESvcAccntUserPwd 
#Write-Host $TDMESvcAccountId " " $TDMESvcAccountPwd
$secpasswd = ConvertTo-SecureString -String $TDMESvcAccountPwd -AsPlainText -Force 
$mycreds = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $TDMESvcAccountId, $secpasswd
Connect-TeamsDeviceManagement -Credential $mycreds #-verbose -debug
$expirationStr = (Get-Date).AddDays(1).ToString()
$otpInfo = $csvObj | New-TeamsDeviceProvisionRequest
$otpInfo | select * | FT

If($otpInfo)
{
    Write-Host $otpInfo.OTP #"-" $otpInfo.Expiration.ToString()
    # TBD: Add RG name and storage name to app settings
    $StorageAccount = Get-AzStorageAccount -ResourceGroupName $ENV:ResourceGroupName -Name $ENV:StorageName
    $ctx = $StorageAccount.Context

    #Get-AzStorageTable –Context $ctx | select Name
    $tableName = $ENV:DevicesTableName
    $storageTable = Get-AzStorageTable –Name $tableName –Context $ctx
    $cloudTable = $storageTable.CloudTable

    #$csvString = $csvString.replace("macAddress","ID")
    #Write-Host "-------------------------"
    Write-Host $csvString
    $devices = $csvString | ConvertFrom-Csv -Delimiter ','
    #[Text.Encoding]::Utf8.GetString([Convert]::FromBase64String($fc.Trim())) | ConvertFrom-Csv -Delimiter ','
    $devices | %{ 
        If(-not $_.RowKey)
        {
            Write-Host "ADD ROW"
            $desc = if($_.description) { $_.description } else { "No description provided" }
            Write-Host $_.macAddress, "MAC Address", $_.Location, $_.UPN, $otpInfo.OTP, $expirationStr, $TriggerMetadata.Name, $desc
            Add-AzTableRow -table $cloudTable -partitionKey $TriggerMetadata.Name.split("_")[0] -rowKey ([Guid]::NewGuid().Guid) -property @{"MacAddress"=$($_.macAddress);"IDType"="MAC Address";"Location"=$($_.Location);"Description"=$desc;"BlobFileName"="$($TriggerMetadata.Name)";"OTP"=$($otpInfo.OTP);"OTPExpiry"=$expirationStr;"ProvisionStatus"="Pending";"RemoteSignStatus"="Pending";"UPN"=$($_.UPN)}
            #-property @{"MacAddress"=$($_.macAddress);"IDType"="MAC Address";"Location"=$($_.Location);"Description"="No description provided";"OTP"=$($otpInfo.OTP);"OTPExpiry"=$($otpInfo.Expiration);"ProvisionStatus"="Pending";"RemoteSignStatus"="Pending";}
            
        }
        else
        {
            Write-Host "UPDATE ROW"
            Write-Host $_.macAddress, "MAC Address", $_.Location, $_.UPN, $_.RowKey
            $device = Get-AzTableRow -table $cloudTable -customFilter "(RowKey eq '$($_.RowKey)')"
            $device.OTP = $otpInfo.OTP
            $device.OTPExpiry = $otpInfo.Expiration
            $device | Update-AzTableRow -table $cloudTable
        }
    }
}
