using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)


$TDMExtensions = ".\Modules\TeamsDeviceManagementExtensions"
Import-Module $TDMExtensions

#Get-Command -Module TeamsDeviceManagementExtensions
$TDMESvcAccountId  = $ENV:TDMESvcAccntUserId 
$TDMESvcAccountPwd = $ENV:TDMESvcAccntUserPwd 
Write-Host $TDMESvcAccountId " " $TDMESvcAccountPwd
$secpasswd = ConvertTo-SecureString -String $TDMESvcAccountPwd -AsPlainText -Force 
$mycreds = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $TDMESvcAccountId, $secpasswd
Connect-TeamsDeviceManagement -Credential $mycreds #-verbose -debug

$StorageAccount = Get-AzStorageAccount -ResourceGroupName 'tdme-rg' -Name 'tdmestorage'
$ctx = $StorageAccount.Context

#Get-AzStorageTable –Context $ctx | select Name
$tableName = "DevicesInfo"
$storageTable = Get-AzStorageTable –Name $tableName –Context $ctx
$cloudTable = $storageTable.CloudTable
Add-AzTableRow -table $cloudTable -partitionKey "testentry-partitionkey" -rowKey ([Guid]::NewGuid().Guid) -property @{"MacAddress"="11:13:11:13:11:11";"IDType"="MAC Address";"Location"="US";"Description"="desc";"BlobFileName"="somefile.csv";"OTP"="1234";"OTPExpiry"="June 1st 2080";"ProvisionStatus"="Pending";"RemoteSignStatus"="Pending";"UPN"="sri@nivas.org"}

$templateblobname = "SampleForProvisioning.csv"
$container = "devicesmanifest"
$newDeviceBlobName = $requestedByUserId +"_"+ [Guid]::NewGuid().Guid +"_NewDeviceRequest.csv"

# Get template blob - which is a sample blob file pre-created in the blob storage
$tempblob = Get-AzStorageBlob -Context $ctx -Container $container -Blob $templateblobname
# Create a new blob file by making a copy of the template file
$tempblob | Start-AzStorageBlobCopy -Context $ctx -DestContext $ctx -DestContainer $container -DestBlob $newDeviceBlobName


# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Interact with query parameters or the body of the request.
$name = $Request.Query.Name
if (-not $name) {
    $name = $Request.Body.Name
}

$body = "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."

if ($name) {
    $body = "Hello, $name. This HTTP triggered function executed successfully."
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $body
})
