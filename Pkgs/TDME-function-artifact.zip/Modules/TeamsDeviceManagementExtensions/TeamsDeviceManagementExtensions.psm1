# TeamsDeviceManagementExtensions
# Version: 0.1.2348.2

# This document is provided "as-is." Information and views expressed in this document,
# including URL and other Internet Web site references, may change without notice. You bear the risk of using it.
# This document does not provide you with any legal rights to any intellectual property in any Microsoft product.
# You may copy and use this document for your internal, reference purposes. You may modify this document for your internal purposes

using namespace System.Diagnostics
using namespace System.Collections
using namespace System.Collections.Generic
using namespace System.Collections.Concurrent
using namespace System.IO
using namespace System.Management.Automation
using namespace System.Management.Automation.Language
using namespace System.Management.Automation.Runspaces
using namespace System.Threading
using namespace System.Text
using namespace System.Net.Http
using namespace System.Net.Http.Headers
using namespace Newtonsoft.Json
using namespace Newtonsoft.Json.Serialization
using namespace Newtonsoft.Json.Converters
using namespace System.Security.Cryptography
using namespace System.Threading.Tasks
using namespace System.Net

# Loading Classes

class RunspaceHandle : IDisposable {
    hidden [ParallelPowerShellRunner] $_pool
    RunspaceHandle([ParallelPowerShellRunner] $pool, [Runspace] $runspace) {
        $this._pool = $pool
        $this.Runspace = $runspace
    }
    [Runspace] $Runspace
    [void] Dispose() {
        $this._pool.Release($this.Runspace)
    }
}

class PowerShellHandle : IDisposable {
    [IAsyncResult] $Job
    [PowerShell] $Pwsh
    [RunspaceHandle] $Handle
    PowerShellHandle([IAsyncResult] $job, [PowerShell] $pwsh, [RunspaceHandle] $handle) {
        $this.Job = $job
        $this.Pwsh = $pwsh
        $this.Handle = $handle
    }

    [void] Dispose() {
        if ($null -ne $this.Pwsh) { try { $this.Pwsh.Dispose() } catch {} }
        if ($null -ne $this.Handle) { try { $this.Handle.Dispose() } catch {} }
    }
}

class ParallelPowerShellRunner {
    hidden [Queue[object]] $PipingInput
    hidden [Queue[PowerShellHandle]] $_runningPwsh
    hidden [PSCmdlet] $cmdlet
    hidden [CancellationToken] $cancellationToken
    hidden [int] $totalCommands
    hidden [int] $completedCommands
    hidden [Type] $RunnerType
    hidden static [int] $MAX_RUNSPACES = 30
    hidden static [int] $PROGRESS_MS = 200
    hidden static [double] $PROGRESS_PCT = 0.01
    hidden static [BlockingCollection[Runspace]] $_runspaces = $null
    hidden static [object] $_sync = [object]::new()
    hidden [ScriptBlock] $ScriptBlock = { Write-Warning 'No script implemented!' }
    hidden [List[string]] $Parameters
    hidden [StopWatch] $timer
    hidden [long] $lastMs
    hidden [int] $lastCompleted

    hidden static [Lazy[HashSet[string]]] $s_defaultVariables = [Lazy[HashSet[string]]]::new(
        [Func[HashSet[string]]] { return [HashSet[string]][string[]]@(
                "$", "?", "^", "_", "args", "ConsoleFileName", "Error", "ErrorView", "Event", "EventArgs",
                "EventSubscriber", "ExecutionContext", "false", "foreach", "HOME", "Host", "input",
                "IsCoreCLR", "IsLinux", "IsMacOS", "IsWindows", "LastExitCode", "Matches", "MyInvocation",
                "NestedPromptLevel", "null", "PID", "PROFILE", "PSBoundParameters", "PSCmdlet",
                "PSCommandPath", "PSCulture", "PSDebugContext", "PSHOME", "PSItem",
                "PSNativeCommandArgumentPassing", "PSScriptRoot", "PSSenderInfo", "PSStyle", "PSUICulture",
                "PSVersionTable", "PWD", "Sender", "ShellId", "StackTrace", "switch", "this", "true") })
    hidden static [HashSet[string]] $DefaultVariables = [ParallelPowerShellRunner]::s_defaultVariables.Value

    hidden static [Lazy[HashSet[string]]] $s_commonParameters = [Lazy[HashSet[string]]]::new(
        [Func[HashSet[string]]] { return [HashSet[string]][string[]]@(
                "Verbose", "Debug", "ErrorAction", "WarningAction", "InformationAction", "ErrorVariable",
                "WarningVariable", "OutVariable", "OutBuffer", "PipelineVariable", "InformationVariable",
                "WhatIf", "Confirm", "UseTransaction") })
    hidden static [HashSet[string]] $CommonParameters = [ParallelPowerShellRunner]::s_commonParameters.Value

    ParallelPowerShellRunner([PSCmdlet] $parentCmdlet) {
        if ($null -eq $parentCmdlet) {
            throw [ArgumentNullException]::new('parentCmdlet')
        }
        $type = $this.GetType()
        $type::Create($type::MAX_RUNSPACES, $type, $null)
        $this.RunnerType = $type
        $this.cancellationToken = [CancellationToken]::new($false)
        $this.PipingInput = [Queue[Dictionary[string, object]]]::new()
        $this._runningPwsh = [Queue[PowerShellHandle]]::new()
        $this.cmdlet = $parentCmdlet
        $this.Parameters = [List[string]]::new()
        $this.totalCommands = 0
        $this.completedCommands = 0
        $this.lastCompleted = 0
        $this.lastMs = 0
        $this.timer = [StopWatch]::StartNew()
    }

    [void] SetScript([ScriptBlock] $sb) {
        $this.cmdlet.WriteDebug("SetScript Enter: {$($sb.ToString())}")
        $sbParams = $sb.Ast.FindAll({ $args[0] -is [ParameterAst] }, $false)
        $autoParams = $sb.Ast.FindAll({ $args[0] -is [VariableExpressionAst] }, $true).Where({ $true }).Where({ $_.VariablePath.UserPath -in @('PSItem', '_', 'args') })
        if ($sbParams.Count -eq 0) {
            $pre = '[CmdletBinding()]param([Parameter(Position=0)]$PSItem)'
            if ($autoParams.Count -gt 0) {
                $pre += '$_=$PSItem;'
            }
            $sb = [ScriptBlock]::Create($pre + $sb.ToString())
        }
        if ($sb.Ast.FindAll({ $args[0] -is [AttributeAst] -and $args[0].TypeName.Name -eq 'CmdletBinding' }, $true).Count -eq 0) {
            # add cmdletbinding so write-verbose etc all work
            $sb = [ScriptBlock]::Create('[CmdletBinding()]' + $sb.ToString())
        }
        $this.Parameters.Clear()
        $this.Parameters.AddRange([ParallelPowerShellRunner]::CommonParameters)
        $sbParams.ForEach({ $this.Parameters.Add($_.Name.VariablePath.UserPath) })
        $this.ScriptBlock = $sb
        $this.ResetIfNeeded()
        $this.cmdlet.WriteDebug("SetScript Exit: {$($this.ScriptBlock.ToString())}")
    }

    [void] QueueInput([PSObject] $i) {
        $Props = $i.PSObject.Properties.Name
        if ($i -is [IDictionary]) {
            $Props = $i.Keys
        }
        if ($i -is [string] -or $i -is [ValueType]) {
            $this.SendInputArgs([PSObject]$i)
            return
        }
        if ($i.GetType().Name -ne 'PSBoundParametersDictionary') {
            foreach ($key in $Props) {
                if ($this.Parameters.Where({ $_.StartsWith($key) }).Count -eq 0) {
                    $this.SendInputArgs([PSObject]$i)
                    return
                }
            }
        }
        $this.cmdlet.WriteVerbose("Adding Command With Parameters (Queued Commands: $($this.PipingInput.Count)): $($this.CommandName()) $($Props.ForEach({"-$($_):$($i.$_ -join ',')"}) -join ' ')")
        $Cloned = [Dictionary[string, object]]::new()
        foreach ($key in $Props) {
            if ($key -eq 'Debug') {
                $this.cmdlet.WriteWarning("Debug is not supported, removing parameter...")
                continue
            }
            $Cloned[$key] = $i.$key
        }
        $this.QueueAndExecute($Cloned)
    }

    [void] ExecuteQueuedCommands() {
        try {
            do {
                $this.ProcessNext()
                $this.ProcessInstance()
            } while ($this.PipingInput.Count -gt 0)
            while ($this._runningPwsh.Count -gt 0) {
                $this.ProcessInstance()
            }
        }
        finally {
            while ($this._runningPwsh.Count -gt 0) {
                $c = $this._runningPwsh.Dequeue()
                $c.Dispose()
            }
        }
    }

    hidden [void] QueueAndExecute([object] $i) {
        $this.totalCommands++
        $this.PipingInput.Enqueue($i)
        $currentCount = $this._runningPwsh.Count
        while ($currentCount -gt 0) {
            $this.ProcessNext()
            $currentCount--
        }
    }

    hidden [void] ProcessNext() {
        if ($this.PipingInput.Count -eq 0) { return }
        if ($this._runningPwsh.Count -ge ($this.RunnerType)::MAX_RUNSPACES) { return }
        $i = $this.PipingInput.Dequeue()
        $handle = $this.Take($this.cancellationToken)
        $pwsh = [PowerShell]::Create()
        $pwsh.Runspace = $handle.Runspace
        try {
            $this.cmdlet.WriteVerbose("Processing Command: $($this.CommandName()) $(if($i -is [IList]) { $i -join ' ' } else { $i.Keys.ForEach({"-$($_):$($i[$_] -join ',')" -join ' ' }) })")
            $pwsh = $this.AddCommand($pwsh)
            if ($i -is [IList]) {
                foreach ($a in $i) {
                    $pwsh = $pwsh.AddArgument($a)
                }
            }
            else {
                $pwsh = $pwsh.AddParameters($i)
            }
            $PwshJob = $pwsh.BeginInvoke()
            $this._runningPwsh.Enqueue([PowerShellHandle]::new($PwshJob, $pwsh, $handle))#, $i))
            $this.WriteProgress()
        }
        catch {
            $e = $_.Exception
            if ($e -is [IContainsErrorRecord]) {
                $this.cmdlet.WriteError([ErrorRecord]::new($e.ErrorRecord, $e))
            }
            else {
                $this.cmdlet.WriteError([ErrorRecord]::new($e, "InvocationFailure", [ErrorCategory]::NotSpecified, $null))
            }
        }
    }

    hidden [void] SendInputArgs([PSObject] $i) {
        $this.cmdlet.WriteVerbose("Adding Command With Args (Queued Commands: $($this.PipingInput.Count)): $($this.CommandName()) $i")
        $this.QueueAndExecute(@($i))
    }

    hidden [InitialSessionState] GetSessionStateForInstance() {
        $sessionState = [InitialSessionState]::CreateDefault2()
        $InitialCommands = $sessionState.Commands.ForEach({ $_.Name.ToString() })
        $InitialVariables = $sessionState.Variables.ForEach({ $_.Name.ToString() })
        $ScriptParameters = $this.ScriptBlock.Ast.FindAll({
                $args[0] -is [ParameterAst] }, $true).Where({ $true }).ForEach({ $_.Name.VariablePath.UserPath })
        $Variables = $this.ScriptBlock.Ast.FindAll({
                $args[0] -is [VariableExpressionAst] }, $true).Where({
                $_.VariablePath.UserPath -notin $ScriptParameters -and ![ParallelPowerShellRunner]::DefaultVariables.Contains($_.VariablePath.UserPath)
            }) | Sort-Object -Property { $_.VariablePath.UserPath } -Unique
        $Assignments = $this.ScriptBlock.Ast.FindAll({
                # We don't want to load any writeable objects, as we will load them as ReadOnly
                $args[0] -is [AssignmentStatementAst] -and $args[0].Left -is [VariableExpressionAst]
            }, $true).Where({ $true }).ForEach({ $_.Left.VariablePath.UserPath })
        $CallStack = Get-PSCallStack # Skip Global Scope
        $Variables.ForEach({
                if ($_.VariablePath.UserPath -in $Assignments) { return }
                if ($_.Parent -is [AssignmentStatementAst]) {
                    if ($_.Parent.Left -eq $_) { return }
                }
                try {
                    $V = $null
                    for ($i = 0; $i -lt $CallStack.Count; $i++) {
                        $V = Get-Variable -Name $_.VariablePath.UserPath -Scope $i -ErrorAction SilentlyContinue
                        if ($null -ne $V) {
                            break
                        }
                    }
                    if ($null -eq $V) {
                        return
                    }
                    $value = $V.Value
                    $sessionState.Variables.Add([SessionStateVariableEntry]::new($_.VariablePath.UserPath, $value, '', [ScopedItemOptions]::ReadOnly))
                }
                catch {
                    $Error.Remove($_)
                }
            })

        $ModulePaths = $env:PSModulePath.Split(';').ForEach({ $_.TrimEnd('\').TrimEnd('/') })
        $ModulePaths += [AppDomain]::CurrentDomain.BaseDirectory.TrimEnd('\').TrimEnd('/')
        $Commands = $this.ScriptBlock.Ast.FindAll({ $args[0] -is [CommandAst] }, $true).Where({
                $_.InvocationOperator -ne [TokenKind]::Ampersand
            }).ForEach({
                $Command = $_.CommandElements[0].Value
                $C = Get-Command -Name $Command | Where-Object { $_.Name -eq $Command }
                if ($C.CommandType -eq 'Alias') {
                    $C = Get-Command -Name $C.ResolvedCommandName
                }
                $base = $C.Module.ModuleBase
                if ($null -eq $base -and $null -ne $C.DLL) { $base = [Path]::GetDirectoryName($C.DLL) }
                if ($null -eq $base -or $ModulePaths.Where({ $base.StartsWith($_) }, 'First', 1).Count -eq 0) {
                    return $C
                }
            })
        $NeedModules, $NoModules = $Commands.Where({ $_.Module -or $_.DLL }, 'Split')
        $Modules = $NeedModules.ForEach({ if ($null -ne $_.Module.Path) { $_.Module.Path } else { $_.DLL } }) | Sort-Object -Unique
        if ($Modules.Count -gt 0) {
            $SBString = $this.ScriptBlock.ToString()
            $extent = $this.ScriptBlock.Ast.ParamBlock.Extent
            $Pre = $SBString.Substring(0, $extent.EndOffset - $this.ScriptBlock.Ast.Extent.StartOffset)
            $Post = $SBString.Substring($extent.EndOffset - $this.ScriptBlock.Ast.Extent.StartOffset)
            $SBString = $Pre + "Import-Module $($Modules.ForEach({"'$($_ -replace "'","''")'"}) -join ',');" + $Post
            $this.ScriptBlock = [ScriptBlock]::Create($SBString)
        }
        $NoModules.ForEach({
                $sessionState.Commands.Add([SessionStateFunctionEntry]::new($_.Name, $_.Definition))
            })
        $Commands = $sessionState.Commands.Where({ $_.Name.ToString() -notin $InitialCommands }).ForEach({ "$($_.Name)" })
        $Variables = $sessionState.Variables.Where({ $_.Name.ToString() -notin $InitialVariables }).ForEach({ "$($_.Name)" })
        if ($Modules.Count -gt 0) {
            $this.cmdlet.WriteDebug("Modules loaded: $($Modules -join ',')")
        }
        if ($Commands.Count -gt 0) {
            $this.cmdlet.WriteDebug("Commands loaded: $($Commands -join ',')")
        }
        if ($Variables.Count -gt 0) {
            $this.cmdlet.WriteDebug("Variables loaded: $($Variables -join ',')")
        }
        return $sessionState
    }

    hidden [void] ResetIfNeeded() {
        $neededState = $this.GetSessionStateForInstance()
        if (($this.RunnerType)::MAX_RUNSPACES -gt ($this.RunnerType)::_runspaces.Count) {
            $this.cmdlet.WriteDebug("Resetting due to lack of available runspaces: Wanted: $(($this.RunnerType)::MAX_RUNSPACES) Got: $(($this.RunnerType)::_runspaces.Count)")
            ($this.RunnerType)::ResetPool(($this.RunnerType)::MAX_RUNSPACES, $this.RunnerType, $neededState)
            return
        }
        $runspace = $this.Take($this.cancellationToken)
        $currentSessionState = $runspace.Runspace.InitialSessionState
        $this.Release($runspace.Runspace)
        $curCom = $currentSessionState.Commands
        $neededCom = $neededState.Commands
        if ($neededCom.Count -gt $curCom.Count) {
            $this.cmdlet.WriteDebug("Resetting due to commands not matching: $($neededCom.Count) $($curCom.Count)")
            ($this.RunnerType)::ResetPool(($this.RunnerType)::MAX_RUNSPACES, $this.RunnerType, $neededState)
            return
        }
        $curComDefHash = [Dictionary[string, object]]::new()
        $curComModHash = [Dictionary[string, object]]::new()
        $curCom.ForEach({ $curComDefHash[$_.Name] = $_.Definition; $curComModHash[$_.Name] = $_.Module })
        foreach ($c in $neededCom) {
            $oc = $null
            $om = $null
            if ($curComDefHash.TryGetValue($c.Name, [ref]$oc)) {
                if ($oc -eq $c.Definition) { continue }
            }
            if ($curComModHash.TryGetValue($c.Name, [ref]$om)) {
                if ($om -eq $c.Module) { continue }
            }
            $this.cmdlet.WriteDebug("Resetting due to commands not matching: $($c.Name)")
            ($this.RunnerType)::ResetPool(($this.RunnerType)::MAX_RUNSPACES, $this.RunnerType, $neededState)
            return
        }
        $curVars = $currentSessionState.Variables
        $neededVars = $neededState.Variables
        if ($neededVars.Count -gt $curVars.Count) {
            $this.cmdlet.WriteDebug("Resetting due to variables not matching: $($neededVars.Count) $($curVars.Count)")
            ($this.RunnerType)::ResetPool(($this.RunnerType)::MAX_RUNSPACES, $this.RunnerType, $neededState)
            return
        }
        $curVarHash = [Dictionary[string, object]]::new()
        $curVars.ForEach({ $curVarHash[$_.Name] = $_.Value })
        foreach ($v in $neededVars) {
            $ov = $null
            if ($curVarHash.TryGetValue($v.Name, [ref]$ov)) {
                if ($ov -eq $v.Value) { continue }
            }
            $this.cmdlet.WriteDebug("Resetting due to variables not matching: $($v.Name)")
            ($this.RunnerType)::ResetPool(($this.RunnerType)::MAX_RUNSPACES, $this.RunnerType, $neededState)
            return
        }
    }

    hidden [RunspaceHandle] Take([CancellationToken] $token) {
        return [RunspaceHandle]::new($this, ($this.RunnerType)::_runspaces.Take($token))
    }

    hidden [void] Release([Runspace] $runspace) {
        ($this.RunnerType)::_runspaces.Add($runspace)
    }

    hidden [void] ProcessInstance() {
        if ($this._runningPwsh.Count -eq 0) { return }
        $this.WriteProgress()
        $handle = $this._runningPwsh.Dequeue()
        $pwsh = $handle.Pwsh
        $job = $handle.Job
        foreach ($debug in $pwsh.Streams.Debug.ReadAll()) {
            $this.cmdlet.WriteDebug($debug.Message)
        }
        foreach ($verbose in $pwsh.Streams.Verbose.ReadAll()) {
            $this.cmdlet.WriteVerbose($verbose.Message)
        }
        foreach ($information in $pwsh.Streams.Information.ReadAll()) {
            $this.cmdlet.WriteInformation($information.MessageData, $null)
        }
        foreach ($warning in $pwsh.Streams.Warning.ReadAll()) {
            $this.cmdlet.WriteWarning($warning.Message)
        }
        foreach ($err in $pwsh.Streams.Error.ReadAll()) {
            $this.cmdlet.WriteError($err)
        }
        if ($Job.IsCompleted) {
            try {
                $result = $pwsh.EndInvoke($Job)
                if (!$pwsh.HadErrors) {
                    $result.Where({ $null -ne $_ }).ForEach({ $this.cmdlet.WriteObject($_, $true) })
                }
            }
            catch {
                $e = $_.Exception
                if ($e -is [IContainsErrorRecord]) {
                    $this.cmdlet.WriteError([ErrorRecord]::new($e.ErrorRecord, $e))
                }
                else {
                    $this.cmdlet.WriteError([ErrorRecord]::new($e, "InvocationFailure", [ErrorCategory]::NotSpecified, $null))
                }
            }
            $this.completedCommands++
            $handle.Dispose()
            return
        }
        $this._runningPwsh.Enqueue($handle)
    }

    hidden [string] $_progressRateString = ""
    hidden [double] $_overallRate = 0
    hidden [ProgressRecord] $_lastUpdate = $null

    hidden [void] WriteProgress() {
        if ($this.totalCommands -eq 0) { return }
        $CurrentMs = $this.timer.ElapsedMilliseconds
        $Elapsed = $CurrentMs - $this.lastMs
        $cInLast = $this.completedCommands - $this.lastCompleted
        if ($Elapsed -lt $this.RunnerType::PROGRESS_MS -and $this.lastMs -ne 0) { return }
        $MessageSb = [StringBuilder]::new()
        $null = $MessageSb.Append("Running: ")
        $null = $MessageSb.Append($this._runningPwsh.Count)
        $null = $MessageSb.Append("; Completed: ")
        $null = $MessageSb.Append($this.completedCommands)
        $null = $MessageSb.Append("/")
        $null = $MessageSb.Append($this.totalCommands)
        if ($Elapsed -gt 0 -and $cInLast -ge ($this.RunnerType::PROGRESS_PCT * $this.totalCommands)) {
            $this._overallRate = $this.completedCommands / ($CurrentMs / 1000)
            $CurrentRate = $cInLast / ($Elapsed / 1000)
            $this._progressRateString = "; Rate: $($this._overallRate.ToString('F2'))/s"

            if ([Math]::Abs($CurrentRate - $this._overallRate) / [Math]::Max($CurrentRate, $this._overallRate) -gt 0.05) {
                $this._progressRateString += ", $($CurrentRate.ToString('F2'))/s for last $cInLast completed"
            }
            $this.lastMs = $this.timer.ElapsedMilliseconds
            $this.lastCompleted = $this.completedCommands
        }
        $null = $MessageSb.Append($this._progressRateString)
        $Progress = [ProgressRecord]::new(
            $this.cmdlet.MyInvocation.PipelinePosition,
            $this.CommandName(),
            $MessageSb.ToString()
        )
        if ($this._overallRate -gt 0) {
            $Remaining = ($this.totalCommands - $this.completedCommands) / $this._overallRate
            if ($Remaining -le [int]::MaxValue -and $Remaining -ge [int]::MinValue) {
                $Progress.SecondsRemaining = $Remaining
            }
        }
        $PctComplete = ($this.completedCommands / $this.totalCommands) * 100
        if ($PctComplete -le [int]::MaxValue -and $PctComplete -ge [int]::MinValue) {
            $Progress.PercentComplete = $PctComplete
        }
        if ($null -eq $this._lastUpdate -or
            $this._lastUpdate.Activity -ne $Progress.Activity -or
            $this._lastUpdate.PercentComplete -ne $Progress.PercentComplete -or
            $this._lastUpdate.SecondsRemaining -ne $Progress.SecondsRemaining) {
            $this.cmdlet.WriteProgress($Progress)
        }
    }

    hidden [PowerShell] AddCommand([PowerShell] $pwsh) {
        return $pwsh.AddScript($this.ScriptBlock.ToString())
    }

    hidden [string] CommandName() {
        return '<ScriptBlock>'
    }

    hidden static [InitialSessionState] GetInitialSessionState() {
        $sessionState = [InitialSessionState]::CreateDefault2()
        return $sessionState
    }

    hidden static [void] ResetPool([int] $amount, [Type] $type, [InitialSessionState] $sessionState) {
        if ($null -eq $type) {
            $type = [ParallelPowerShellRunner]
        }
        if ($null -eq $sessionState) {
            $sessionState = $type::GetInitialSessionState()
        }
        $type::Create(0, $type, $sessionState)
        $type::Create($amount, $type, $sessionState)
    }

    hidden static [void] Clear([Type] $type) {
        if ($null -eq $type) {
            $type = [ParallelPowerShellRunner]
        }
        $lockWasTaken = $false
        [Monitor]::Enter($type::_sync, [ref] $lockWasTaken)
        try {
            while ($type::_runspaces.Count -gt 0) {
                $r = $type::_runspaces.Take()
                if ($null -ne $r) { $r.Dispose() }
            }
            $type::_runspaces = $null
        }
        finally {
            if ($lockWasTaken) { [Monitor]::Exit($type::_sync) }
        }
    }

    hidden static [void] Create([int] $amount, [Type] $type, [InitialSessionState] $sessionState) {
        if ($null -eq $type) {
            $type = [ParallelPowerShellRunner]
        }
        if ($null -eq $sessionState) {
            $sessionState = $type::GetInitialSessionState()
        }
        if ($null -eq $type::_runspaces -or $type::_runspaces.Count -ne $amount) {
            $lockWasTaken = $false
            [Monitor]::Enter($type::_sync, [ref] $lockWasTaken)
            try {
                if ($null -eq $type::_runspaces -or $type::_runspaces.Count -ne $amount) {
                    if ($null -eq $type::_runspaces) {
                        $type::_runspaces = [BlockingCollection[Runspace]]::new()
                    }
                    while ($type::_runspaces.Count -lt $amount) {
                        $runspace = [RunspaceFactory]::CreateRunspace($sessionState)
                        $runspace.Open()
                        $type::_runspaces.Add($runspace)
                    }
                    while ($type::_runspaces.Count -gt $amount) {
                        $r = $type::_runspaces.Take()
                        if ($null -ne $r) { $r.Dispose() }
                    }
                }
            }
            finally {
                if ($lockWasTaken) { [Monitor]::Exit($type::_sync) }
            }
        }
    }
}

class ParallelCmdletRunner : ParallelPowerShellRunner {
    hidden [CommandInfo] $commandInfo
    hidden static [int] $MAX_RUNSPACES = 30
    hidden static [BlockingCollection[Runspace]] $_runspaces = $null
    hidden static [object] $_sync = [object]::new()

    hidden Init([CommandInfo] $commandInfo, [PSCmdlet] $parentCmdlet) {
        $this.commandInfo = $commandInfo
        $this.ScriptBlock = $null
        $commandInfo.Parameters.Keys.ForEach({ $this.Parameters.Add($_) })
    }

    ParallelCmdletRunner([CommandInfo] $commandInfo, [PSCmdlet] $parentCmdlet) : base($parentCmdlet) {
        $this.Init($commandInfo, $parentCmdlet)
    }

    ParallelCmdletRunner([string] $commandName, [PSCmdlet] $parentCmdlet) : base($parentCmdlet) {
        $info = Get-Command -Name $commandName
        $this.Init($info, $parentCmdlet)
    }

    [void] SetScript([ScriptBlock] $sb) {}

    hidden [PowerShell] AddCommand([PowerShell] $pwsh) {
        return $pwsh.AddCommand($this.commandInfo.Name)
    }

    hidden [string] CommandName() {
        return $this.commandInfo.Name
    }
}

class ConnectionInfo {
    hidden static [object] $_lock = [object]::new()
    hidden static [ConnectionInfo] $CurrentConnection = $null
    hidden static [HttpClient] $Client
    static [string[]] $Scopes = [string[]]@('https://devicemgmt.teams.microsoft.com/.default')

    hidden [PSCustomObject] $_jwt
    [string] $Token
    [AuthenticationHeaderValue] $Header
    [DateTime] $ExpiresAt
    [HashTable] $RenewParams

    ConnectionInfo([PSCustomObject] $TokenResponse, [IDictionary] $Params) {
        $this.Token = $TokenResponse.access_token
        $this.Header = [AuthenticationHeaderValue]::new('Bearer', $this.Token)
        $this.ExpiresAt = [DateTime]::Now.AddSeconds($TokenResponse.expires_in)
        $this.RenewParams = @{}
        foreach ($key in $Params.Keys) {
            $this.RenewParams[$key] = $Params[$key]
        }
        $this | Add-Member -MemberType ScriptProperty -Name JWT -Value {
            if ($null -eq $this._jwt) {
                $Body = $this.Token.Split('.')[1]
                while (($Body.Length % 4) -gt 0) {
                    $Body += '='
                }
                $this._jwt = ([Encoding]::UTF8.GetString([Convert]::FromBase64String($Body)) | ConvertFrom-Json)
            }
            return $this._jwt
        }
        $this | Add-Member -MemberType ScriptProperty -TypeName bool -Name Expired -Value { $this.ExpiresAt -le [DateTime]::Now }
    }

    [bool] ExpiredIn([int] $ExpiresInMinutes) {
        return $this.ExpiresAt.AddMinutes(-$ExpiresInMinutes) -le [DateTime]::Now
    }
    [void] UpdateToken([ConnectionInfo] $NewToken) {
        if ($this.RenewParams.Keys.Count -ne $NewToken.RenewParams.Keys.Count) { return }
        if ($this.ExpiresAt -gt $NewToken.ExpiresAt) { return }
        $this.Token = $NewToken.Token
        $this.Header = $NewToken.Header
        $this.ExpiresAt = $NewToken.ExpiresAt
        $this.RenewParams = $NewToken.RenewParams
    }
}

class GraphConnectionInfo : ConnectionInfo {
    hidden static [object] $_lock = [object]::new()
    hidden static [GraphConnectionInfo] $CurrentConnection = $null
    hidden static [HttpClient] $Client
    static [string[]] $Scopes = [string[]]@('https://graph.microsoft.com/Directory.AccessAsUser.All')
    GraphConnectionInfo([PSCustomObject] $TokenResponse, [IDictionary] $Params) : base($TokenResponse, $Params) {}
}

enum ProvisioningOperationType {
    UNKNOWN
    CREATE
    UPDATE
    GENERATE_ENROLLMENT
}

enum PairingStatus {
    Unknown
    NotPaired
    Paired
}

enum DeviceType {
    Unknown
    IpPhone
    TeamsRoom
    SurfaceHub
    CollaborationBar
    TeamsDisplay
    TouchConsole
    LowCostPhone
    TeamsPanel
    Sip
    SipAnalog
}

enum DeviceCategory {
    RoomSystem
    IpPhone
    SurfaceHub
}

enum UserType {
    Unknown
    CommonArea
    Conference
    Personal
}

enum UserStatus {
    Unknown
    SignedIn
    SignedOut
}

enum DeviceStatus {
    Online
    Offline
    Unenrolled
    Blocked
}

enum ProvisionMethod {
    UNKNOWN
    TEAMS_USER
    OTP
}

enum UniqueIdType {
    UNKNOWN
    MAC_ID
    SERIAL_NUMBER
    HARDWARE_ID_ANALOG
}

enum HealthState {
    Unkown
    Offline
    Critical
    NonUrgent
    Healthy
}

enum HealthStatus {
    Unknown
    Healthy
    Unhealthy
}

enum InterfaceType {
    UNKNOWN
    WIFI
    ETHERNET
}

enum ConnectionStatus {
    Unknown
    Disconnected
    Connected
}

enum MeetingState {
    Unknown
    SfbMeeting
    TeamsMeeting
    ThirdPartyMeeting
    HdmiIngest
    Idle
    Busy
    Unavailable
}

enum UsageState {
    Unknown
    Idle
    Busy
    Unavailable
}

class BaseClass {
    [string] ToString() {
        return [JsonConvert]::SerializeObject($this, [BaseClass]::SerializerSettings)
    }

    static [JsonSerializerSettings] $SerializerSettings
    static BaseClass() {
        [BaseClass]::SerializerSettings = [JsonSerializerSettings]@{
            NullValueHandling = [NullValueHandling]::Ignore
            Formatting        = [Formatting]::None
            ContractResolver  = [DefaultContractResolver]@{ NamingStrategy = [CamelCaseNamingStrategy]::new() }
        }
        [BaseClass]::SerializerSettings.Converters.Add([StringEnumConverter]::new())
        [BaseClass]::SerializerSettings.Converters.Add([UnixDateTimeConverter]::new())
    }
}

class Enrollment : BaseClass {
    [JsonConverter([StringEnumConverter])]
    [ProvisionMethod] $Method
    [EnrollmentData] $EnrollmentMethodData
}

class EnrollmentData : BaseClass {
    [string] $OTP
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [JsonConverter([UnixDateTimeConverter])]
    [DateTimeOffset] $OTPExpiry
}

class User : BaseClass {
    [string] $UserId
    [string] $UserName
    [string] $UPN
}

class BaseInfo : BaseClass {
    [string] $Id = $null
    [string] $CreatedBy = $null
    [string] $ModifiedBy = $null
    [string] $CreatedByUserName = $null
    [string] $ModifiedByUserName = $null
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [JsonConverter([UnixDateTimeConverter])]
    [Nullable[DateTimeOffset]] $CreatedAt = $null
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [JsonConverter([UnixDateTimeConverter])]
    [Nullable[DateTimeOffset]] $ModifiedAt = $null
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [JsonConverter([UnixDateTimeConverter])]
    [Nullable[DateTimeOffset]] $DeletedAt = $null
}

class DeviceModel : BaseClass {
    [string] $Id
    [string] $Manufacturer
    [string] $Model
}

class ConfigProfileRef : BaseClass {
    [string] $ConfigId
    [string] $Name
}

class NetworkStatus : BaseClass {
    [JsonConverter([StringEnumConverter])]
    [ConnectionStatus] $ConnectionStatus
}

class UsageStateSummary : BaseClass {
    [JsonConverter([StringEnumConverter])]
    [MeetingState] $MeetingState
    [JsonConverter([StringEnumConverter])]
    [UsageState] $UsageState
    [JsonConverter([UnixDateTimeConverter])]
    [DateTimeOffset] $Since
}

class HealthSummary : BaseClass {
    [NetworkStatus] $NetworkStatus
    [JsonConverter([StringEnumConverter])]
    [HealthStatus] $HealthStatus
    [JsonConverter([UnixDateTimeConverter])]
    [DateTimeOffset] $Since
    [JsonConverter([StringEnumConverter])]
    [HealthState] $HealthState
    [int] $HealthIssuesCount
    [SoftwareHealth] $SoftwareHealth
}

class SoftwareHealth : BaseClass {
    [bool] $UpgradeAvailable
    [Dictionary[string, string]] $SoftwareUpdates
}

class Tag : BaseClass {
    [string] $Id
    [IList[string]] $Sources
}

class ProvisioningUniqueId : BaseClass {
    [UniqueIdType] $Type
    [string] $UniqueId
}

class ProvisionInfo : BaseClass {
    [ProvisionMethod] $ProvisionMethod
    [bool] $FirstSignInDone
    [string] $AssignedLocation
    [ProvisioningUniqueId]$UniqueId
}

class MacAddressInfo : BaseClass {
    [string] $MACAddress
    [JsonConverter([StringEnumConverter])]
    [InterfaceType] $InterfaceType
}

class TeamsUnProvisionedDevice : BaseClass {
    [BaseInfo] $BaseInfo
    [string] $AssignedLocation
    [JsonProperty(PropertyName = 'uniqueIdRef')]
    [ProvisioningUniqueId] $UniqueId
    [JsonProperty(PropertyName = 'enrollmentRef')]
    [Enrollment] $Enrollment
    [string] $Model
    [string] $Manufacturer
    [ProvisioningOperationType] $LastOperationType
    [IList[string]] $AdministrativeUnitIds
}

class TenantRef : BaseClass {
    [string] $TenantId
}

class DeviceId : BaseClass {
    [string] $UniqueId
    [string] $OEMSerialNumber
    [string] $DeviceHostName
    [IList[string]] $MacAddresses
}

class LicenseDetails : BaseClass {
    [License] $EffectiveLicense
    [string] $EffectiveLicenseExperience
    [JsonConverter([UnixDateTimeConverter])]
    [DateTimeOffset] $UpdatedAt
}

class License : BaseClass {
    [string] $SkuId
    [string] $FriendlyName
}

class Workspace : BaseClass {
    [string] $WorkspaceId
    [bool] $IsWorkspaceIdUpdated
}

class TeamsIdentifier : BaseClass {
    [string] $TeamsGeneratedDeviceId
    [IList[string]] $AggregatedDeviceIds
}

class AdministrationConfig : BaseClass {
    [int] $AutoUpdateFrequencyInDays
}

class TeamsDevice : BaseClass {
    [BaseInfo] $BaseInfo
    [JsonProperty(PropertyName = 'userRef')]
    [User] $User
    [JsonProperty(PropertyName = 'lastLoggedInUserRef')]
    [User] $LastLoggedInUser
    [JsonConverter([StringEnumConverter])]
    [DeviceType] $DeviceType
    [JsonProperty(PropertyName = 'configRef')]
    [ConfigProfileRef] $Config
    [IList[Tag]] $TagList
    [ProvisionInfo] $ProvisionInfo
    [IList[MacAddressInfo]] $MacAddressInfos
    [JsonProperty(PropertyName = 'deviceModelRef')]
    [DeviceModel] $DeviceModel
    [string] $DeviceName
    [string] $IPAddress
    [IList[string]] $AdministrativeUnitIds
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Dictionary[string, string]] $SoftwareUpdates
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [object] $SoftwareVersions
    [JsonConverter([StringEnumConverter])]
    [PairingStatus] $PairingStatus
    [JsonConverter([StringEnumConverter])]
    [UserType] $UserType
    [DeviceId] $DeviceIds
    [JsonProperty(PropertyName = 'tenantRef')]
    [TenantRef] $Tenant
    [string] $Notes
    [string] $CompanyAssetTag
    [HealthSummary] $HealthSummary
    [UsageStateSummary] $UsageStateSummary
    [DeviceCategory] $DeviceCategory
    [JsonProperty(PropertyName = 'workspaceRef')]
    [Workspace] $Workspace
    [LicenseDetails] $LicenseDetails
    [TeamsIdentifier] $TeamsIdentifier
    [AdministrationConfig] $AdministrationConfig
}

class DecoratedTeamsDevice : TeamsDevice {
    DecoratedTeamsDevice([TeamsDevice]$d) : base() {
        foreach ($i in $d.PSObject.Properties.Name) {
            $this.$i = $d.$i
        }
    }
    [PSCredential] $Credential = $null
}

class TeamsDeviceResponse : BaseClass {
    [TeamsDevice[]] $Devices
    [string] $ContinuationToken
}

class IndividualResponse : BaseClass {
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [string] $Id
    [int] $StatusCode
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [string] $ErrorCode
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [List[string]] $Errors
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [object] $Response
}

class BulkCreateResponse : BaseClass {
    [int] $StatusCode
    [List[IndividualResponse]] $Responses
}

class BulkResponse : BaseClass {
    [int] $StatusCode
    [Dictionary[string, IndividualResponse]] $Responses
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [string] $ContinuationToken
}

class ConfigProfile : BaseClass {
    [BaseInfo] $BaseInfo
    [string] $Identity
    [string] $Description
    [int] $ConfigProfileCreationType
    [bool] $DeviceLock
    [ValidateRange(30, 3600)]
    [int] $DeviceLockTimeout = 30
    [string] $DeviceLockPin
    [string] $Language = [string]::Empty
    [string] $TimeZone = [string]::Empty
    [string] $TimeZoneId = [string]::Empty
    [ValidateRange(0, 2)]
    [int] $TimeDst
    [string] $DateFormat
    [string] $TimeFormat
    [bool] $DisplayScreenSaver
    [ValidateRange(30, 3600)]
    [int] $ScreenSaverTimeout = 900
    [ValidateRange(0, 100)]
    [int] $DisplayBacklitBrightness = 80
    [ValidateRange(30, 3600)]
    [int] $DisplayBacklitTimeout = 900
    [bool] $DisplayHighContrast
    [bool] $SilentMode
    [string] $OfficeStartHours = [string]::Empty
    [string] $OfficeEndHours = [string]::Empty
    [bool] $PowerSaving
    [bool] $LoggingEnabled
    [string] $LoggingTypes
    [string] $NetworkDhcp
    [bool] $NetworkPcPort
    [string] $DeviceDefaultAdminPassword = [string]::Empty
    [bool] $ScreenCapture
    [int] $AssignedTo
    [bool] $LANPort
    [bool] $DHCPEnabled
    [string] $HostName
    [string] $DomainName
    [string] $IPAddress
    [string] $SubnetMask
    [string] $DefaultGateway
    [string] $PrimaryDNS
    [string] $SecondaryDNS
    [JsonConverter([StringEnumConverter])]
    [DeviceType] $DeviceType
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $HideMeetingNames
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $UsageStateIndicator
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Color] $UsageStateIndicatorBusyStateColor
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $CheckinNotification
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [CheckinRoomReleaseConfig] $CheckinRoomReleaseConfig
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Theme] $Theme
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $RoomCapacityNotificationEnabled
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $IsIPPhonePremiumCapSkuEnabled
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $IsRoomEquipmentEnabled
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $BluetoothBeconingEnabled
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $BYOMAutoAcceptEnabled
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $AllowRoomRemoteEnabled
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [DeviceAppRestartConfig] $DeviceAppRestartConfig
}

class Color : BaseClass {
    [string] $Name = [string]::Empty
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[int]] $R
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[int]] $G
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[int]] $B
}

class CheckinRoomReleaseConfig : BaseClass {
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $Enabled
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[int]] $Timeout
}

class Theme : BaseClass {
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [string] $Name = [string]::Empty
}

class DeviceAppRestartConfig : BaseClass {
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $IsDeviceAppRestartEnabled
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[bool]] $IsDeviceAppAutoRestartEnabled
    [JsonProperty(NullValueHandling = [NullValueHandling]::Ignore)]
    [Nullable[int]] $ScheduledDeviceAppRestartTime
}

class ConfigProfileResponse : BaseClass {
    [IList[ConfigProfile]] $PaginatedConfigProfiles
    [string] $ContinuationToken
}

# Loading Functions

# HandleCmsiInterrupt
function HandleCmsiInterrupt {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable]
        $NextStepParams,

        [Parameter(Mandatory = $true, ValueFromPipeline = $false)]
        [Hashtable]
        $BoundParams
    )
    process {
        Write-Debug "$($MyInvocation.MyCommand.Name):  Next:`n$($NextStepParams | ConvertTo-Json -Depth 5)"
        Write-Debug "$($MyInvocation.MyCommand.Name): Bound:`n$($BoundParams | ConvertTo-Json -Depth 5)"
        $null = $NextStepParams.Remove('PageId')
        $NextStepParams['Body']['ContinueAuth'] = $true
    }
}

# HandleConvergedChangePassword
function HandleConvergedChangePassword {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable]
        $NextStepParams,

        [Parameter(Mandatory = $true, ValueFromPipeline = $false)]
        [Hashtable]
        $BoundParams
    )
    process {
        Write-Debug "$($MyInvocation.MyCommand.Name):  Next:`n$($NextStepParams | ConvertTo-Json -Depth 5)"
        Write-Debug "$($MyInvocation.MyCommand.Name): Bound:`n$($BoundParams | ConvertTo-Json -Depth 5)"
        $BeginUri = $NextStepParams['BeginUri']
        $PollUri = $NextStepParams['PollUri']

        $null = $NextStepParams.Remove('PageId')
        $null = $NextStepParams.Remove('BeginUri')
        $null = $NextStepParams.Remove('PollUri')
        $NewPassword = New-Password -Length 16
        $BodyParams = $NextStepParams['Body'].Keys.Where({ $_ -ne 'canary' })

        $RequestBody = @{
            NewPassword = [System.Net.NetworkCredential]::new('', $NewPassword).Password
            OldPassword = $BoundParams['Credential'].GetNetworkCredential().Password
        }
        foreach ($p in $BodyParams) {
            $RequestBody[$p] = $NextStepParams['Body'][$p]
        }
        $IRMParams = @{
            Uri         = $BeginUri
            Method      = 'POST'
            Body        = $RequestBody | ConvertTo-Json -Compress
            ContentType = 'application/json; charset=UTF-8'
            WebSession  = $NextStepParams['Session']
            Verbose     = $false
        }
        $Response = Invoke-RestMethod @IRMParams
        Write-Debug "$($MyInvocation.MyCommand.Name): Begin:`n$($Response | ConvertTo-Json -Depth 5)"

        foreach ($p in $BodyParams) {
            $NextStepParams['Body'][$p] = $Response.$p
        }
        $JobPending = $Response.IsJobPending
        while ($JobPending) {
            $RequestBody = @{
                CoupledDataCenter = $Response.CoupledDataCenter
                CoupledScaleUnit  = $Response.CoupledScaleUnit
            }
            foreach ($p in $BodyParams) {
                $RequestBody[$p] = $NextStepParams['Body'][$p]
            }
            $IRMParams = @{
                Uri         = $PollUri
                Method      = 'POST'
                Body        = $RequestBody | ConvertTo-Json -Compress
                ContentType = 'application/json; charset=UTF-8'
                WebSession  = $NextStepParams['Session']
                Verbose     = $false
                ErrorAction = 'Stop'
            }
            try {
                $Response = Invoke-RestMethod @IRMParams
            }
            catch {
                $NextStepParams['Uri'] = $null
                break
            }
            Write-Debug "$($MyInvocation.MyCommand.Name): Poll:`n$($Response | ConvertTo-Json -Depth 5)"
            if ($null -ne $Response.ErrorMessage) {
                Write-Error $Response.ErrorMessage
                $NextStepParams['Uri'] = $null
            }
            $JobPending = $Response.IsJobPending
        }
        foreach ($p in $BodyParams) {
            $NextStepParams['Body'][$p] = $Response.$p
        }

        $NextStepParams['Body']['currentpasswd'] = $BoundParams['Credential'].GetNetworkCredential().Password
        $BoundParams['Credential'] = [PSCredential]::new($BoundParams['Credential'].Username, $NewPassword)
        $NextStepParams['Body']['newpasswd'] = $BoundParams['Credential'].GetNetworkCredential().Password
        $NextStepParams['Body']['confirmnewpasswd'] = $NextStepParams['Body']['newpasswd']
    }
}

# HandleConvergedConsent
function HandleConvergedConsent {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable]
        $NextStepParams,

        [Parameter(Mandatory = $true, ValueFromPipeline = $false)]
        [Hashtable]
        $BoundParams
    )
    process {
        Write-Debug "$($MyInvocation.MyCommand.Name):  Next:`n$($NextStepParams | ConvertTo-Json -Depth 5)"
        Write-Debug "$($MyInvocation.MyCommand.Name): Bound:`n$($BoundParams | ConvertTo-Json -Depth 5)"
        $ConsentSb = [Text.StringBuilder]::new()
        foreach ($Scope in $NextStepParams['ScopesToConsent']) {
            $null = $ConsentSb.AppendLine("$([Net.WebUtility]::HtmlDecode($Scope.label)): $([Net.WebUtility]::HtmlDecode($Scope.description))")
        }
        Write-Warning "Requires Consent!"
        Write-Warning $ConsentSb.ToString()
        if ($null -eq $PSCmdlet.Host -or !$PSCmdlet.Host.UI.SupportsVirtualTerminal) {
            # cannot consent with a non-interactive shell
            $NextStepParams['Uri'] = $null
            return
        }
        $ReadHost = Read-Host -Prompt 'Do you want to allow this access? [No]'
        $Consent = $null -ne $ReadHost -and $ReadHost.ToLower() -in @('y', 'yes')
        $NextStepParams['Body']['acceptConsent'] = $Consent
        $null = $NextStepParams.Remove('ScopesToConsent')
        $null = $NextStepParams.Remove('PageId')
    }
}

# HandleConvergedError
function HandleConvergedError {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable]
        $NextStepParams,

        [Parameter(Mandatory = $true, ValueFromPipeline = $false)]
        [Hashtable]
        $BoundParams
    )
    process {
        Write-Debug "$($MyInvocation.MyCommand.Name):  Next:`n$($NextStepParams | ConvertTo-Json -Depth 5)"
        Write-Debug "$($MyInvocation.MyCommand.Name): Bound:`n$($BoundParams | ConvertTo-Json -Depth 5)"
        $ErrorMessageBuilder = [Text.StringBuilder]::new()
        $null = $ErrorMessageBuilder.Append($NextStepParams.MainMessage)
        if (![string]::IsNullOrEmpty($NextStepParams.AdditionalMessage)) {
            $null = $ErrorMessageBuilder.Append(": ")
            $null = $ErrorMessageBuilder.Append($NextStepParams.AdditionalMessage)
        }
        $null = $ErrorMessageBuilder.AppendLine()
        $null = $ErrorMessageBuilder.Append("`t")
        $null = $ErrorMessageBuilder.Append($NextStepParams.ServiceExceptionMessage)
        Write-Error -Message $ErrorMessageBuilder.ToString()
    }
}

# HandleConvergedMessage
function HandleConvergedMessage {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable]
        $NextStepParams,

        [Parameter(Mandatory = $true, ValueFromPipeline = $false)]
        [Hashtable]
        $BoundParams
    )
    process {
        Write-Debug "$($MyInvocation.MyCommand.Name):  Next:`n$($NextStepParams | ConvertTo-Json -Depth 5)"
        Write-Debug "$($MyInvocation.MyCommand.Name): Bound:`n$($BoundParams | ConvertTo-Json -Depth 5)"
        Write-Information "$($NextStepParams.Message)"
    }
}

# HandleConvergedRemoteConnect
function HandleConvergedRemoteConnect {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable]
        $NextStepParams,

        [Parameter(Mandatory = $true, ValueFromPipeline = $false)]
        [Hashtable]
        $BoundParams
    )
    process {
        Write-Debug "$($MyInvocation.MyCommand.Name):  Next:`n$($NextStepParams | ConvertTo-Json -Depth 5)"
        Write-Debug "$($MyInvocation.MyCommand.Name): Bound:`n$($BoundParams | ConvertTo-Json -Depth 5)"
        if ($BoundParams['Code'] -notmatch $NextStepParams.Pattern) {
            throw "$($BoundParams['Code']) is not a valid Device Code!"
        }
        $IRMParams = @{
            Uri         = $NextStepParams['Uri'] + '?code=' + $BoundParams['Code']
            Method      = 'Get'
            WebSession  = $NextStepParams['Session']
            ErrorAction = 'SilentlyContinue'
            Verbose     = $false
        }
        $Response = Invoke-RestMethod @IRMParams
        Write-Debug "$($MyInvocation.MyCommand.Name):  Get:`n$($Response | ConvertTo-Json -Depth 5)"
        $null = $NextStepParams.Remove('Pattern')
        $null = $NextStepParams.Remove('PageId')
        $NextStepParams['Body']['otc'] = $BoundParams['Code']
    }
}

# HandleConvergedSignIn
function HandleConvergedSignIn {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable]
        $NextStepParams,

        [Parameter(Mandatory = $true, ValueFromPipeline = $false)]
        [Hashtable]
        $BoundParams
    )
    process {
        Write-Debug "$($MyInvocation.MyCommand.Name):  Next:`n$($NextStepParams | ConvertTo-Json -Depth 5)"
        Write-Debug "$($MyInvocation.MyCommand.Name): Bound:`n$($BoundParams | ConvertTo-Json -Depth 5)"
        $ValidationErrors = $NextStepParams['ValidationErrors']
        $GetUri = $NextStepParams['GetUri']
        $Country = $NextStepParams['Country']
        $null = $NextStepParams.Remove('PageId')
        $null = $NextStepParams.Remove('GetUri')
        $null = $NextStepParams.Remove('Country')
        $null = $NextStepParams.Remove('ValidationErrors')

        if ($ValidationErrors.Count -gt 0 -and $null -ne $Script:EstsError) {
            if ($EstsError.Values.Where({ $ValidationErrors -contains $_ }, 'First', 1).Count -gt 0) {
                Write-Warning "Validation Errors! $($ValidationErrors.ForEach({
                    $e = $_
                    $val = $EstsError.GetEnumerator().Where({$_.Value -eq $e},'First',1)[0].Key
                    if ($null -eq $val) { $val = $e }
                    $val }) -join ', ')"
                $NextStepParams['Uri'] = $null
                return
            }
        }

        $RequestBody = @{
            username        = $BoundParams['Credential'].Username
            originalRequest = $NextStepParams['Body']['ctx']
            country         = $Country
            flowToken       = $NextStepParams['Body']['flowToken']
        }
        $IRMParams = @{
            Uri         = $GetUri
            Method      = 'POST'
            Body        = $RequestBody | ConvertTo-Json -Compress
            ContentType = 'application/json; charset=UTF-8'
            WebSession  = $NextStepParams['Session']
            Verbose     = $false
        }
        $Response = Invoke-RestMethod @IRMParams
        Write-Debug "$($MyInvocation.MyCommand.Name): Get:`n$($Response | ConvertTo-Json -Depth 5)"

        $NextStepParams['Body']['flowToken'] = $Response.FlowToken
        Write-Debug "$($MyInvocation.MyCommand.Name): HasCertAuth: $($Response.Credentials.HasCertAuth)"
        Write-Debug "$($MyInvocation.MyCommand.Name): CertAuthUrl: $($Response.Credentials.CertAuthParams.CertAuthUrl)"
        if ((![string]::IsNullOrEmpty($BoundParams['CertificateThumbprint']) -or $null -ne $BoundParams['Certificate']) -and
            $Response.Credentials.HasCertAuth -and
            ![string]::IsNullOrEmpty($Response.Credentials.CertAuthParams.CertAuthUrl)) {
            $Body = @{
                ctx       = $NextStepParams['Body']['ctx']
                flowToken = $NextStepParams['Body']['flowToken']
            }
            $IRMParams = @{
                Uri     = $Response.Credentials.CertAuthParams.CertAuthUrl
                Method  = 'Post'
                Body    = $Body
                Verbose = $false
            }
            if (![string]::IsNullOrEmpty($BoundParams['CertificateThumbprint'])) {
                $IRMParams['CertificateThumbprint'] = $BoundParams['CertificateThumbprint']
            }
            else {
                $IRMParams['Certificate'] = $BoundParams['Certificate']
            }
            Write-Debug "$($MyInvocation.MyCommand.Name): CertIRMParams:`n$($IRMParams | ConvertTo-Json -Depth 5)"
            if ($IRMParams['WebSession'].Cookies.Count -gt 0 -and $PSEdition -ne 'Desktop') {
                Write-Debug "Cookies:`n       $($IRMParams['WebSession'].Cookies.GetAllCookies().ForEach({"$($_.Name ):$($_.Value) ($($_.Domain))"}) -join "`n       ")"
            }
            Start-Sleep -Milliseconds 100
            $Response = Invoke-RestMethod @IRMParams
            Write-Debug "$($MyInvocation.MyCommand.Name): CertResp:`n$($Response.OuterXml)"
            $Payload = $Response.GetElementsByTagName('form').Where({ $_.name -eq 'hiddenform' }, 'First', 1)[0]
            $NextStepParams['Uri'] = $Payload.action
            $Payload.input.Where({ $_.name -in @('certificatetoken', 'login') }).ForEach({
                    $NextStepParams['Body'][$_.name] = $_.value
                })
        }
        elseif (![string]::IsNullOrEmpty($Response.Credentials.FederationRedirectUrl)) {
            $Federation = Invoke-RestMethod -Uri $Response.Credentials.FederationRedirectUrl
            Write-Debug "$($MyInvocation.MyCommand.Name): Federation`n$Federation"
            Write-Warning "Account redirects to federated partner! $($Response.Credentials.FederationRedirectUrl)"
            $NextStepParams['Uri'] = $null
        }
        elseif ($Response.IfExistsResult -ne 0) {
            Write-Warning "Account Does not exist! $($Response.Username) : $($Response.IfExistsResult)"
            $NextStepParams['Uri'] = $null
        }
        else {
            $NextStepParams['Body']['login'] = $BoundParams['Credential'].Username
            $NextStepParams['Body']['passwd'] = $BoundParams['Credential'].GetNetworkCredential().Password
        }
    }
}

# HandleConvergedTFA
function HandleConvergedTFA {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable]
        $NextStepParams,

        [Parameter(Mandatory = $true, ValueFromPipeline = $false)]
        [Hashtable]
        $BoundParams
    )
    process {
        Write-Debug "$($MyInvocation.MyCommand.Name):  Next:`n$($NextStepParams | ConvertTo-Json -Depth 5)"
        Write-Debug "$($MyInvocation.MyCommand.Name): Bound:`n$($BoundParams | ConvertTo-Json -Depth 5)"
        $null = $NextStepParams.Remove('PageId')
        if ($null -eq $PSCmdlet.Host -or !$PSCmdlet.Host.UI.SupportsVirtualTerminal) {
            # cannot do MFA with a non-interactive shell
            $NextStepParams['Uri'] = $null
            $null = $NextStepParams.Remove('PollingBackoffInterval')
            $null = $NextStepParams.Remove('PerAuthPollingInterval')
            $null = $NextStepParams.Remove('UserProofs')
            $null = $NextStepParams.Remove('BeginUri')
            $null = $NextStepParams.Remove('EndUri')
            return
        }

        $UserProofs = $NextStepParams['UserProofs']
        $UserProof = $null
        if ($UserProofs.Count -eq 1) {
            $UserProof = $UserProofs[0]
        }
        $Default = $UserProofs.Where({ $_.IsDefault })[0]
        $DefaultId = 0
        if ($null -ne $Default) {
            $DefaultId = $UserProofs.IndexOf($Default)
        }
        $DefaultIdStr = "$($DefaultId + 1)"
        Write-Debug "$($MyInvocation.MyCommand.Name): MFA Options:`n$($UserProofs | ConvertTo-Json -Depth 5)"
        while ($null -eq $UserProof) {
            Write-Information "Available Multi-Factor Options:"
            for ($i = 0; $i -lt $UserProofs.Count; $i++) {
                $IdString = if ($i -eq $DefaultId) { " [$DefaultIdStr]:" } else { "  $($i + 1): " }
                Write-Information "$IdString $($UserProofs[$i].AuthMethodId) $($UserProofs[$i].display)"
            }
            $ProofIdStr = Read-Host "Please select an option [$DefaultIdStr]"
            if ([string]::IsNullOrEmpty($ProofIdStr)) {
                $ProofIdStr = $DefaultIdStr
            }
            $Id = 0
            if ([int]::TryParse($ProofIdStr.Trim(), [ref] $Id) -and $Id -le $UserProofs.Count -and $Id -ge 1) {
                $UserProof = $UserProofs[($Id - 1)]
            }
        }
        Write-Debug "$($MyInvocation.MyCommand.Name):  UserProof:`n$($UserProof | ConvertTo-Json -Depth 5)"
        $MethodId = $UserProof.AuthMethodId

        $IRMParams = @{
            Uri         = $NextStepParams['BeginUri']
            Method      = 'Post'
            Body        = @{
                AuthMethodId = $MethodId
                Method       = 'BeginAuth'
                ctx          = $NextStepParams['Body']['ctx']
                flowToken    = $NextStepParams['Body']['flowToken']
            } | ConvertTo-Json -Compress
            ContentType = 'application/json'
        }
        Write-Verbose -Message "$($MyInvocation.MyCommand.Name): $($IRMParams['Method'].ToUpper()) $($IRMParams['Uri'])"
        $Response = Invoke-RestMethod @IRMParams
        Write-Debug "$($MyInvocation.MyCommand.Name):  Begin:`n$($Response | ConvertTo-Json -Depth 5)"
        $NextStepParams['Body']['ctx'] = $Response.Ctx
        $NextStepParams['Body']['flowToken'] = $Response.FlowToken

        $PollCount = 0
        do {
            $Body = @{
                AuthMethodId = $MethodId
                Method       = 'EndAuth'
                ctx          = $NextStepParams['Body']['ctx']
                flowToken    = $NextStepParams['Body']['flowToken']
                SessionId    = $Response.SessionId
                PollCount    = ++$PollCount
            }
            if ($PollCount -eq 1) {
                if ($MethodId -in @('OneWaySMS', 'PhoneAppOTP')) {
                    # 'TwoWayVoiceMobile'
                    $Code = Read-Host -Prompt "Enter the code from the $(if($MethodId.StartsWith('PhoneApp')){ "OTP app on" } else { "message sent to" }) $($UserProof.display)"
                    $Body['AdditionalAuthData'] = $Code
                }
                else {
                    Write-Information "Please approve the sign-in request"
                }
                if ($Response.Entropy -gt 0) {
                    Write-Information "Enter the number $($Response.Entropy) using the authenticator on $($UserProof.display)"
                }
            }

            if ($PollCount -gt 1) {
                Start-Sleep -Seconds 5
                $Body['LastPollStart'] = [long]([DateTime]::UtcNow - [DateTime]::new(1970, 1, 1, 0, 0, [DateTimeKind]::Utc)).TotalMilliseconds
                $Body['LastPollEnd'] = $cPollEnd
            }
            else {
                $pollStart = [long]([DateTime]::UtcNow - [DateTime]::new(1970, 1, 1, 0, 0, [DateTimeKind]::Utc)).TotalMilliseconds
            }
            $IRMParams = @{
                Uri         = $NextStepParams['EndUri']
                Method      = 'Post'
                Body        = $Body | ConvertTo-Json -Compress
                ContentType = 'application/json'
            }
            Write-Verbose -Message "$($MyInvocation.MyCommand.Name): $($IRMParams['Method'].ToUpper()) $($IRMParams['Uri'])"
            $Response = Invoke-RestMethod @IRMParams
            $cPollEnd = [long]([DateTime]::UtcNow - [DateTime]::new(1970, 1, 1, 0, 0, [DateTimeKind]::Utc)).TotalMilliseconds
            Write-Debug "$($MyInvocation.MyCommand.Name):  End:`n$($Response | ConvertTo-Json -Depth 5)"
            $NextStepParams['Body']['ctx'] = $Response.Ctx
            $NextStepParams['Body']['flowToken'] = $Response.FlowToken
        } while ($Response.Retry -and $PollCount -le 10)

        if ($null -ne $Code) {
            $NextStepParams['Body']['otc'] = $Code
        }
        $NextStepParams['Body']['mfaAuthMethod'] = $MethodId
        $NextStepParams['Body']['mfaLastPollStart'] = $pollStart
        $NextStepParams['Body']['mfaLastPollEnd'] = $cPollEnd

        $null = $NextStepParams.Remove('PollingBackoffInterval')
        $null = $NextStepParams.Remove('PerAuthPollingInterval')
        $null = $NextStepParams.Remove('UserProofs')
        $null = $NextStepParams.Remove('BeginUri')
        $null = $NextStepParams.Remove('EndUri')
    }
}

# HandleKmsiInterrupt
function HandleKmsiInterrupt {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable]
        $NextStepParams,

        [Parameter(Mandatory = $true, ValueFromPipeline = $false)]
        [Hashtable]
        $BoundParams
    )
    process {
        Write-Debug "$($MyInvocation.MyCommand.Name):  Next:`n$($NextStepParams | ConvertTo-Json -Depth 5)"
        Write-Debug "$($MyInvocation.MyCommand.Name): Bound:`n$($BoundParams | ConvertTo-Json -Depth 5)"
        $null = $NextStepParams.Remove('PageId')
        $NextStepParams['Body']['ContinueAuth'] = $true
    }
}

# HandleRawHTML
function HandleRawHTML {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable]
        $NextStepParams,

        [Parameter(Mandatory = $true, ValueFromPipeline = $false)]
        [Hashtable]
        $BoundParams
    )
    process {
        Write-Debug "$($MyInvocation.MyCommand.Name):  Next:`n$($NextStepParams | ConvertTo-Json -Depth 5)"
        Write-Debug "$($MyInvocation.MyCommand.Name): Bound:`n$($BoundParams | ConvertTo-Json -Depth 5)"
        $null = $NextStepParams.Remove('PageId')
        if ($null -ne $NextStepParams['Body']) {
            # if ($null -ne $NextStepParams['Body']['ctx']) {
            #     $NextStepParams['Session'].Certificates = $null
            #     return
            # }
            $NextStepParams['Uri'] = $null
            return [PSCustomObject]$NextStepParams['Body']
        }
    }
}

# HandleUnhandled
function HandleUnhandled {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable]
        $NextStepParams,

        [Parameter(Mandatory = $true, ValueFromPipeline = $false)]
        [Hashtable]
        $BoundParams
    )
    process {
        Write-Debug "$($MyInvocation.MyCommand.Name):  Next:`n$($NextStepParams | ConvertTo-Json -Depth 5)"
        Write-Debug "$($MyInvocation.MyCommand.Name): Bound:`n$($BoundParams | ConvertTo-Json -Depth 5)"
        $NextStepParams['Uri'] = $null
        Write-Error -TargetObject $NextStepParams -Message "$($NextStepParams['PageId']) is not handled!"
    }
}

# ConvertFrom-EncodedBase64String
function ConvertFrom-EncodedBase64String {
    [CmdletBinding()]
    [OutputType([byte[]])]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [string]
        $String
    )
    end {
        $String = $String.Replace('_', '/').Replace('-', '+')
        while (($String.Length % 4) -ne 0) { $String += '=' }
        return [Convert]::FromBase64String($String)
    }
}

# ConvertTo-EncodedBase64String
function ConvertTo-EncodedBase64String {
    [CmdletBinding()]
    [OutputType([string])]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [byte[]]
        $Bytes
    )
    end {
        $String = [Convert]::ToBase64String($Bytes)
        return $String.Replace('/', '_').Replace('+', '-').TrimEnd('=')
    }
}

# Get-Sha256Base64Hash
function Get-Sha256Base64Hash {
    [CmdletBinding()]
    [OutputType([string])]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [string]
        $String
    )
    end {
        $sha = [System.Security.Cryptography.SHA256]::Create()
        try {
            return ConvertTo-EncodedBase64String -Bytes ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($String)))
        }
        finally {
            if ($null -ne $sha) { $sha.Dispose() }
        }
    }
}

# GetJsonObject
function ParseValue {
    param (
        [Parameter(Mandatory, Position = 0, ValueFromPipeline)]
        [AllowNull()]
        [AllowEmptyString()]
        [string]
        $Value
    )
    process {
        if ($null -eq $Value -or [string]::IsNullOrEmpty($Value)) {
            return $null
        }
        $Value = $Value.Trim()
        if ($Value.StartsWith('{') -and $Value.EndsWith('}')) {
            $objValue = [ordered]@{}
            $Value = $Value.TrimStart('{').TrimEnd('}')
            foreach ($kvp in $value -split '\s*,\s*') {
                $k, $v = $kvp -split '\s*:\s*', 2
                if (!$k.StartsWith('"') -and !$k.EndsWith('"') -and $k -match '\W') {
                    continue
                }
                $k = $k.Trim('"').Trim()
                if ([string]::IsNullOrEmpty($k)) {
                    continue
                }
                $v = ParseValue -Value $v
                if ($null -ne $v) { $objValue[$k] = $v }
            }
            if ($objValue.Count -gt 0) {
                return $objValue
            }
            return
        }
        elseif ($Value.StartsWith('[') -and $Value.EndsWith(']')) {
            $objValue = [List[object]]@()
            $Value = $Value.TrimStart('[').TrimEnd(']')
            foreach ($v in $value -split '\s*,\s*') {
                $v = ParseValue -Value $v
                if ($null -eq $v) { continue }
                $objValue.Add($v)
            }
            if ($objValue.Count -gt 0) {
                return $objValue
            }
            return
        }
        elseif ($Value -eq '!0' -or $Value -eq 'false') {
            return $false
        }
        elseif ($Value -eq '!1' -or $Value -eq 'true') {
            return $true
        }
        elseif ($Value.StartsWith('"') -and $Value.EndsWith('"')) {
            return $Value.Trim('"')
        }
        elseif ($Value.StartsWith('/') -and $Value.EndsWith('/')) {
            # regex
            return $Value.Trim('/')
        }
        elseif ($Value -match '^\d+\.\d\d*$') {
            return [double]$Value
        }
        elseif ($Value -match '^\d+$') {
            return [int]$Value
        }
        else {
            # Write-Debug "InvalidValue: '$Value'"
        }
    }
}

function ParseBlob {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0, ValueFromPipeline)]
        [string]
        $Blob
    )
    process {
        $objValue = ParseValue -Value $Blob
        if ($null -ne $objValue) {
            $objValue | Write-Output
        }
    }
}

function GetJsonObject {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, Position = 0, ValueFromPipeline)]
        [string]
        $StringContent
    )
    begin {
        if ($null -eq $Script:ObjectValuePattern) {
            $Script:ObjectValuePattern = [Regex]'(?<=\b)\w+\s*=\s*\{["\w]+(?>\{(?<brace>)|[^\{\}]+|\}(?<-brace>))*(?(brace)(?!))\}'
        }

        if ($null -eq $Script:ObjectPattern) {
            $Script:ObjectPattern = [Regex]'(?<!\w+\s*?=\s*?)(?<!\)\s*(?:\r?\n)*\s*)\{(?:\s*(?:\r?\n)*\s*\w+|"[^"]+")\s*(?:\r?\n)*\s*:(?>\{(?<brace>)|[^\{\}]+|\}(?<-brace>))*(?(brace)(?!))\}'
        }
    }
    process {
        $values = [HashSet[string]]@()
        $parsedRanges = [List[Range]]@()
        $ObjectValueBlobs = $ObjectValuePattern.Matches($StringContent).Where({ $_.Success }) | Sort-Object -Property Index #.ForEach({ $_.Groups[0].Value })
        $ObjectData = [ordered]@{}
        foreach ($objectValue in $ObjectValueBlobs) {
            $range = [Range]::new($objectValue.Index, $objectValue.Index + $objectValue.Length)
            $objectValue = $objectValue.Groups[0].Value
            Write-Debug "Parsing $objectValue"
            $key, $value = $objectValue -split '\s*=\s*', 2
            $key = $key.Trim()
            $value = $value.Trim()
            # $null = $values.Add($value)
            $valueObject = ParseBlob -Blob $value
            if ($null -ne $valueObject) {
                $ObjectData[$key] = $valueObject
            }
            $parsedRanges.Add($range)
        }
        if ($ObjectData.Count -gt 0) {
            $ObjectData | Write-Output
        }
        $ObjectBlobs = $ObjectPattern.Matches($StringContent).Where({ $_.Success }) | Sort-Object -Property Index #.ForEach({ $_.Groups[0].Value })
        foreach ($object in $ObjectBlobs) {
            $range = [Range]::new($object.Index, $object.Index + $object.Length)
            if ($parsedRanges.Where({ $_.Start.Value -le $range.Start.Value -and $_.End.Value -ge $range.End.Value }, 'First', 1).Count -gt 0) {
                continue
            }
            $object = $object.Groups[0].Value.Trim()
            if (!$values.Add($object)) { continue }
            Write-Debug "Parsing $object"
            $valueObject = ParseBlob -Blob $object
            if ($null -ne $valueObject) {
                $parsedRanges.Add($range)
                $valueObject | Write-Output
            }
        }
    }
}

# Invoke-EstsMethod
function Invoke-EstsMethod {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]
        $Uri,

        [Parameter(Mandatory = $true, Position = 1)]
        [Microsoft.PowerShell.Commands.WebRequestSession]
        $Session,

        [Parameter(Mandatory = $false, Position = 2)]
        [HashTable]
        $Body,

        [Parameter(Mandatory = $false, Position = 3)]
        [string]
        $RedirectUri
    )
    begin {
        $BaseUri = 'https://login.microsoftonline.com'
    }
    process {
        try {
            do {
                $IRMParams = @{
                    Uri                = $Uri
                    WebSession         = $Session
                    ErrorAction        = 'Stop'
                    Method             = if ($null -ne $Body) { 'Post' } else { 'Get' }
                    Verbose            = $false
                    MaximumRedirection = 0
                }
                Write-Verbose -Message "$($MyInvocation.MyCommand.Name): $($IRMParams['Method'].ToUpper()) $($IRMParams['Uri'])"
                if ($null -ne $Body) {
                    $IRMParams['Body'] = $Body
                    $IRMParams['ContentType'] = 'application/x-www-form-urlencoded'
                    Write-Debug "$($MyInvocation.MyCommand.Name): BODY: `n       $($Body.Keys.ForEach({"${_}:$($Body[$_])"}) -join "`n       ")"
                }
                if ($Session.Headers.Count -gt 0) {
                    Write-Debug "Headers:`n       $($Session.Headers.Keys.ForEach({"${_}:$($Session.Headers[$_])"}) -join "`n       ")"
                }
                if ($Session.Cookies.Count -gt 0 -and $PSEdition -ne 'Desktop') {
                    Write-Debug "Cookies:`n       $($Session.Cookies.GetAllCookies().ForEach({"$($_.Name ):$($_.Value) ($($_.Domain))"}) -join "`n       ")"
                }
                try {
                    $PageResponse = Invoke-RestMethod @IRMParams
                    break
                }
                catch {
                    # need to move from IRM to HttpClient to avoid issues with WindowsPowerShell and redirects - otherwise we cannot get the returned tokens
                    if (([int]($_.Exception.Response.StatusCode)) -in @(301, 302)) {
                        $Target = $_.Exception.Response.Headers.Location[0]
                        Write-Verbose "$($_.Exception.Response.StatusCode): $($Target.AbsoluteUri)"
                        if ($null -ne $RedirectUri -and $Target.AbsoluteUri.StartsWith($RedirectUri)) {
                            $Results = $Target.GetComponents([UriComponents]::Fragment -bor [UriComponents]::Query, [UriFormat]::Unescaped)
                            if (![string]::IsNullOrEmpty($Results)) {
                                $Results = $Results.TrimStart('#').TrimStart('?')
                                $ReturnPayload = @{}
                                $Results = $Results.Split('&')
                                if ($Results.Count -gt 0) {
                                    $Results.ForEach({
                                            $r = $_.Split('=')
                                            $ReturnPayload[$r[0]] = [Uri]::UnescapeDataString($r[1])
                                        })
                                    $NextStep = @{
                                        PageId  = 'RawHTML'
                                        Uri     = $null
                                        Session = $Session
                                        Body    = $ReturnPayload
                                    }
                                    return $NextStep
                                }
                            }
                        }

                        $Prior = ($u = [Uri]$Uri).scheme + '://' + $u.Host + '/'
                        $Session.Headers.Referer = $Prior
                        $Uri = $Target
                        $Body = $null
                        continue
                    }
                    throw
                }
            } while ($true)

            $JsonObjects = @($PageResponse | GetJsonObject)
            $PageConfig = $JsonObjects.Where({ $_ -is [IDictionary] -and $null -ne $_['Config'] }, 'First', 1)[0].Config
            if ($null -eq $PageConfig -and $PageResponse.IndexOf('$Config=') -gt -1) {
                $PageConfig = (($PageResponse -split '\$Config=')[1] -split ";`r?`n")[0] | ConvertFrom-Json
                Write-Debug "$($MyInvocation.MyCommand.Name): Using legacy page config"
                Write-Debug "JSONOBJECTS: $($JsonObjects | ConvertTo-Json -Depth 5)"
                Write-Debug "PAGERESPONSE: $PageResponse"
            }
            if ($null -ne ($apiErr = $JsonObjects.Where({ $_ -is [IDictionary] -and $null -ne $_['ApiErrorCodes'] }, 'First', 1)[0].ApiErrorCodes)) {
                $Script:ApiErrorCodes = [hashtable]$apiErr
            }
            if ($null -ne ($estsErr = $JsonObjects.Where({ $_ -is [IDictionary] -and $null -ne $_['EstsError'] }, 'First', 1)[0].EstsError)) {
                $Script:EstsError = [hashtable]$estsErr
            }

            if ($null -ne $PageConfig.pgid) {
                Write-Debug "$($MyInvocation.MyCommand.Name): Got Page: $($PageConfig.pgid)"
                Write-Debug "$($MyInvocation.MyCommand.Name): Config:`n$($PageConfig | ConvertTo-Json -Depth 5)"
                if ($null -ne $PageConfig.urlPost -and ![Uri]::IsWellFormedUriString($PageConfig.urlPost, [UriKind]::Absolute)) {
                    $PageConfig.urlPost = "$BaseUri$($PageConfig.urlPost)"
                }
                $NextStep = @{
                    PageId  = $PageConfig.pgid
                    Uri     = $PageConfig.urlPost
                    Session = $Session
                    Body    = @{
                        canary              = $PageConfig.canary
                        ctx                 = $PageConfig.sCtx
                        $PageConfig.sFTName = $PageConfig.sFT
                    }
                }
                switch ($PageConfig.pgid) {
                    "ConvergedMessage" {
                        $NextStep['Title'] = $PageConfig.sTitle
                        $NextStep['Message'] = $PageConfig.sMessage
                    }
                    "ConvergedRemoteConnect" {
                        $NextStep['Pattern'] = $PageConfig.sUserCodeRegex
                    }
                    "ConvergedTFA" {
                        $NextStep['UserProofs'] = $PageConfig.arrUserProofs
                        $NextStep['BeginUri'] = $PageConfig.urlBeginAuth
                        $NextStep['EndUri'] = $PageConfig.urlEndAuth
                        $NextStep['PollingBackoffInterval'] = $PageConfig.iPollingBackoffInterval
                        $NextStep['PerAuthPollingInterval'] = @{}
                        $PageConfig.oPerAuthPollingInterval.PSObject.Properties.Name.ForEach({
                                $NextStep['PerAuthPollingInterval'][$_] = $PageConfig.oPerAuthPollingInterval.$_
                            })
                        $NextStep['Body']['login'] = $PageConfig.sPOST_Username
                    }
                    # "KmsiInterrupt" { return $PageConfig }
                    "ConvergedChangePassword" {
                        if (![Uri]::IsWellFormedUriString($PageConfig.urlAsyncSsprBegin, [UriKind]::Absolute)) {
                            $PageConfig.urlAsyncSsprBegin = "$BaseUri$($PageConfig.urlAsyncSsprBegin)"
                        }
                        if (![Uri]::IsWellFormedUriString($PageConfig.urlAsyncSsprPoll, [UriKind]::Absolute)) {
                            $PageConfig.urlAsyncSsprPoll = "$BaseUri$($PageConfig.urlAsyncSsprPoll)"
                        }
                        $NextStep['BeginUri'] = $PageConfig.urlAsyncSsprBegin
                        $NextStep['PollUri'] = $PageConfig.urlAsyncSsprPoll
                    }
                    "ConvergedError" {
                        $NextStep['MainMessage'] = $PageConfig.strMainMessage
                        $NextStep['AdditionalMessage'] = $PageConfig.strAdditionalMessage
                        $NextStep['ServiceExceptionMessage'] = $PageConfig.strServiceExceptionMessage
                    }
                    "ConvergedConsent" {
                        $NextStep['ScopesToConsent'] = $PageConfig.arrScopes
                    }
                    "ConvergedSignIn" {
                        $NextStep['Country'] = $PageConfig.country
                        $NextStep['GetUri'] = $PageConfig.urlGetCredentialType
                        $NextStep['ValidationErrors'] = $PageConfig.arrValErrs
                    }
                }
            }
            elseif ($null -ne $PageResponse -and $PageResponse -isnot [string]) {
                # need to handle non-json response better...
                $Payload = $PageResponse.GetElementsByTagName('form').Where({ $_.name -eq 'hiddenform' }, 'First', 1)[0]
                $PayloadBody = @{}
                $Payload.input.ForEach({
                        $PayloadBody[$_.name] = $_.value
                    })
                $NextStep = @{
                    PageId  = 'RawHTML'
                    Uri     = $Payload.action
                    Session = $Session
                    Body    = $PayloadBody
                }
                if ($Payload.input.Count -eq 0) {
                    $null = $NextStep.Remove('Body')
                }
            }
            else {
                Write-Debug "$($MyInvocation.MyCommand.Name): RawContent:`n$PageResponse"
            }

            Write-Debug "$($MyInvocation.MyCommand.Name): NextStepParams:`n$($NextStep | ConvertTo-Json -Depth 4)"
            return $NextStep
        }
        catch {
            Write-Warning $_.Exception.Message
        }
    }
}

# New-CodeVerifier
function New-CodeVerifier {
    [CmdletBinding()]
    param ()
    end {
        $buffer = [byte[]]::new(96)
        $randomSource = [RandomNumberGenerator]::Create()
        try {
            $randomSource.GetBytes($buffer)
            return ConvertTo-EncodedBase64String -Bytes $buffer
        }
        finally {
            if ($null -ne $randomSource) { $randomSource.Dispose() }
        }
    }
}

# Get-OAuth2TokenFromCredential
function Get-OAuth2TokenFromCredential {
    [CmdletBinding()]
    [OutputType([ConnectionInfo])]
    param (
        [Parameter(Mandatory = $true)]
        [string[]]
        $Scope,

        [Parameter(Mandatory = $true, Position = 0, ParameterSetName = 'Credential')]
        [PSCredential]
        $Credential,

        [Parameter(Mandatory = $true, Position = 0, ParameterSetName = 'CertificateThumbprint')]
        [Parameter(Mandatory = $true, Position = 0, ParameterSetName = 'Certificate')]
        [string]
        $UserName,

        [Parameter(Mandatory = $true, Position = 1, ParameterSetName = 'CertificateThumbprint')]
        [string]
        $CertificateThumbprint,

        [Parameter(Mandatory = $true, Position = 1, ParameterSetName = 'Certificate')]
        [Security.Cryptography.X509Certificates.X509Certificate2]
        $Certificate,

        [Parameter(Mandatory = $false)]
        [AllowEmptyString()]
        [string]
        $ClientId = "12128f48-ec9e-42f0-b203-ea49fb6af367",

        [Parameter(Mandatory = $false)]
        [string]
        $RedirectUri,

        [Type]
        $Type = [ConnectionInfo],

        [Parameter(Mandatory = $false)]
        [string]
        $Tenant
    )
    begin {
        Write-Debug "$($MyInvocation.MyCommand.Name)$($PSBoundParameters.Keys.ForEach({" -$($_):$($PSBoundParameters[$_] -join ',')"}) -join '')"
    }
    end {
        $null = $PSBoundParameters.Remove('Type')
        $PSBoundParameters['AuthorizationCodeFlow'] = $true
        try {
            $TokenResponse = Invoke-SignInRequest @PSBoundParameters
            if ($null -eq $TokenResponse) { return $null }
            $null = $PSBoundParameters.Remove('AuthorizationCodeFlow')
            return $Type::new($TokenResponse, $PSBoundParameters)
        }
        catch {
            Write-Warning $_.Exception.Message
            $ContentTask = $_.Exception.Response.Content.ReadAsStringAsync()
            $ContentTask.Wait()
            Write-Warning $ContentTask.Result
        }
    }
}

# Invoke-SignInRequest
function Invoke-SignInRequest {
    [CmdletBinding(DefaultParameterSetName = 'Token')]
    param (
        [Parameter(Mandatory = $true, ParameterSetName = 'DCF')]
        [Parameter(Mandatory = $true, ParameterSetName = 'Token')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintDCFCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintTokenCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateDCFCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateTokenCredential')]
        [PSCredential]
        $Credential,

        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintDCFUserName')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintTokenUserName')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateDCFUserName')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateTokenUserName')]
        [string]
        $UserName,

        [Parameter(Mandatory = $true, ParameterSetName = 'Token')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintTokenCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintTokenUserName')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateTokenCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateTokenUserName')]
        [string]
        $ClientId,

        [Parameter(Mandatory = $true, ParameterSetName = 'Token')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintTokenCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintTokenUserName')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateTokenCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateTokenUserName')]
        [string[]]
        $Scope,

        [Parameter(Mandatory = $false, ParameterSetName = 'Token')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateThumbprintTokenCredential')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateThumbprintTokenUserName')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateTokenCredential')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateTokenUserName')]
        [string]
        $RedirectUri = 'https://login.microsoftonline.com/common/oauth2/nativeclient',

        [Parameter(Mandatory = $false, ParameterSetName = 'Token')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateThumbprintTokenCredential')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateThumbprintTokenUserName')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateTokenCredential')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateTokenUserName')]
        [string]
        $Authority = 'https://login.microsoftonline.com/',

        [Parameter(Mandatory = $false, ParameterSetName = 'Token')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateThumbprintTokenCredential')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateThumbprintTokenUserName')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateTokenCredential')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateTokenUserName')]
        [string]
        $Tenant = 'common',

        [Parameter(Mandatory = $true, ParameterSetName = 'DCF')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateDCFCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateDCFUserName')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintDCFCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintDCFUserName')]
        [string]
        $Code,

        [Parameter(Mandatory = $false, ParameterSetName = 'DCF')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateThumbprintDCFCredential')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateDCFCredential')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateThumbprintDCFUserName')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateDCFUserName')]
        [string]
        $Uri = 'https://microsoft.com/devicelogin',

        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintDCFCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintTokenCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintDCFUserName')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateThumbprintTokenUserName')]
        [string]
        $CertificateThumbprint,

        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateDCFCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateTokenCredential')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateDCFUserName')]
        [Parameter(Mandatory = $true, ParameterSetName = 'CertificateTokenUserName')]
        [Security.Cryptography.X509Certificates.X509Certificate2]
        $Certificate,

        [switch]
        $Version1,

        [Parameter(Mandatory = $false, ParameterSetName = 'Token')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateThumbprintTokenCredential')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateThumbprintTokenUserName')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateTokenCredential')]
        [Parameter(Mandatory = $false, ParameterSetName = 'CertificateTokenUserName')]
        [switch]
        $AuthorizationCodeFlow,

        [ValidateRange(0, 100)]
        [int]
        $MaximumSteps = 5
    )
    begin {
        $Handlers = @{
            ConvergedError          = $ExecutionContext.InvokeCommand.GetCommand('HandleConvergedError', 'Function')
            ConvergedMessage        = $ExecutionContext.InvokeCommand.GetCommand('HandleConvergedMessage', 'Function')
            CmsiInterrupt           = $ExecutionContext.InvokeCommand.GetCommand('HandleCmsiInterrupt', 'Function')
            KmsiInterrupt           = $ExecutionContext.InvokeCommand.GetCommand('HandleKmsiInterrupt', 'Function')
            ConvergedSignIn         = $ExecutionContext.InvokeCommand.GetCommand('HandleConvergedSignIn', 'Function')
            ConvergedRemoteConnect  = $ExecutionContext.InvokeCommand.GetCommand('HandleConvergedRemoteConnect', 'Function')
            ConvergedConsent        = $ExecutionContext.InvokeCommand.GetCommand('HandleConvergedConsent', 'Function')
            ConvergedChangePassword = $ExecutionContext.InvokeCommand.GetCommand('HandleConvergedChangePassword', 'Function')
            RawHTML                 = $ExecutionContext.InvokeCommand.GetCommand('HandleRawHTML', 'Function')
            # ConvergedProofUpRedirect - need to enable MFA page
            ConvergedTFA            = $ExecutionContext.InvokeCommand.GetCommand('HandleConvergedTFA', 'Function')
            Unhandled               = $ExecutionContext.InvokeCommand.GetCommand('HandleUnhandled', 'Function')
        }
    }
    end {
        $NextStepParams = @{
            Uri     = $Uri
            Session = [Microsoft.PowerShell.Commands.WebRequestSession]::new()
        }

        if ($PSCmdlet.ParameterSetName -like '*Token*') {
            $NextStepParams['RedirectUri'] = $RedirectUri
            $Scope = $Scope + @('openid', 'profile') | Sort-Object -Unique
            if ($AuthorizationCodeFlow) {
                $Verifier = New-CodeVerifier
                $Challenge = $Verifier | Get-Sha256Base64Hash
                $Scope = $Scope + @('openid', 'profile') | Sort-Object -Unique
                $Query = @{
                    response_type         = "code"
                    client_id             = $ClientId
                    redirect_uri          = $RedirectUri
                    scope                 = $Scope -join ' '
                    code_challenge        = $Challenge
                    code_challenge_method = 'S256'
                }
            }
            else {
                $Query = @{
                    response_type = 'token'  # could also do 'token id_token'
                    client_id     = $ClientId
                    redirect_uri  = $RedirectUri
                    scope         = $Scope -join ' '
                    nonce         = [Guid]::NewGuid().Guid
                    response_mode = 'form_post'
                }
            }
            $Version = if (!$Version1) { '/v2.0' } else { '' }
            $NextStepParams['Uri'] = '{0}/{1}/oauth2{2}/authorize?{3}' -f $Authority.TrimEnd('/'), $Tenant.TrimEnd('/'), $Version, ($Query.Keys.ForEach({ "$_=$([Uri]::EscapeDataString($Query[$_]))" }) -join '&')
        }
        if ($null -eq $Credential) {
            $Credential = [PSCredential]::new($UserName, [SecureString]::new())
            $null = $PSBoundParameters.Remove('UserName')
            $PSBoundParameters['Credential'] = $Credential
        }
        $RemainingSteps = $MaximumSteps
        while ($null -ne $NextStepParams['Uri'] -and ($RemainingSteps--) -gt 0) {
            Write-Debug "$($MyInvocation.MyCommand.Name): $($RemainingSteps) $([string]::new('-',20))"
            $NextStepParams = Invoke-EstsMethod @NextStepParams
            if ($null -eq $NextStepParams) {
                Write-Warning "Unknown Failure!"
                break
            }
            $Handler = $Handlers[$NextStepParams['PageId']]
            if ($null -eq $Handler) {
                $Handler = $Handlers['Unhandled']
            }
            $Results = & $Handler -NextStepParams $NextStepParams -BoundParams $PSBoundParameters
            if ($null -ne $Results) {
                break
            }
            # sleeping between calls to ensure CSRF doesn't break.
            Start-Sleep -Milliseconds 100
        }
        if ($null -ne $Results) {
            if ($AuthorizationCodeFlow -and $Results.code) {
                $IRMParams = @{
                    Method  = 'Post'
                    Body    = @{
                        grant_type    = 'authorization_code'
                        client_id     = $ClientId
                        redirect_uri  = $RedirectUri
                        scope         = $Scope -join ' '
                        client_info   = 1
                        code_verifier = $Verifier
                        code          = $Results.code
                    }
                    Verbose = $false
                }
                $Version = if (!$Version1) { '/v2.0' } else { '' }
                $IRMParams['Uri'] = '{0}/{1}/oauth2{2}/token' -f $Authority.TrimEnd('/'), $Tenant.TrimEnd('/'), $Version
                return Invoke-RestMethod @IRMParams
            }
            return $Results
        }
    }
}

# New-Password
function New-Password {
    [CmdletBinding()]
    param(
        [ValidateRange(8, 256)]
        [int]
        $Length = 256
    )
    begin {
        $UpperChars = [byte][char]'A'..[byte][char]'Z'
        $LowerChars = [byte][char]'a'..[byte][char]'z'
        $DigitChars = [byte][char]'0'..[byte][char]'9'
        $SpecialChars = [byte][char]' '..[byte][char]'/' + [byte][char]':'..[byte][char]'@' + [byte][char]'['..[byte][char]'`' + [byte][char]'{'..[byte][char]'~'
    }
    end {
        while ($true) {
            $Upper = 0
            $Lower = 0
            $Digits = 0
            $Special = 0
            $Local:Password = [SecureString]::new()
            Get-Random -Minimum 32 -Maximum 126 -Count $Length | ForEach-Object {
                $Local:Char = [char]$_
                $Local:Password.AppendChar($Local:Char)
                switch ([byte]$Char) {
                    { $_ -in $UpperChars } { $Upper++; break; }
                    { $_ -in $LowerChars } { $Lower++; break; }
                    { $_ -in $DigitChars } { $Digits++; break; }
                    { $_ -in $SpecialChars } { $Special++; break; }
                }
            }
            $Entropy = 0d
            $Entropy += $Upper * [Math]::Log($UpperChars.Count, 2)
            $Entropy += $Lower * [Math]::Log($LowerChars.Count, 2)
            $Entropy += $Digits * [Math]::Log($DigitChars.Count, 2)
            $Entropy += $Special * [Math]::Log($SpecialChars.Count, 2)
            if (@($Upper, $Lower, $Digits, $Special).Where({ $_ -gt 0 }).Count -ge 3) {
                return $Local:Password
            }
            Write-Verbose "Invalid password, regenerating..."
        }
    }
}

# Assert-TeamsDeviceManagementConnected
function Assert-TeamsDeviceManagementConnected {
    [CmdletBinding()]
    param ()
    end {
        if ($null -eq [ConnectionInfo]::CurrentConnection) {
            throw "$($MyInvocation.MyCommand.Module.Name) is not connected! Run $(
                $MyInvocation.MyCommand.Module.ExportedCommands.Where({$_.Verb -eq 'Connect'},'First',1)[0].Name
                ) before continuing."
        }
    }
}

# CleanMACAddress
$Script:MACSeparators = [Collections.Generic.HashSet[string]]@('-', ':', '.')
$Script:MACRegex = [Regex]::new('([0-9A-F]{2})', [Text.RegularExpressions.RegexOptions]::IgnoreCase)
filter CleanMACAddress {
    ($Script:MACRegex.Split($_).Where({ $_ -notin $Script:MACSeparators }) -join '').ToLower()
}

# Get-OAuth2TokenHeader
function Get-OAuth2TokenHeader {
    [CmdletBinding()]
    param (
        [Parameter(ValueFromPipeline = $true, Mandatory = $true, Position = 0)]
        [ConnectionInfo]
        $TokenResponse,
        [int]
        $ExpiresInMinutes = 5
    )
    end {
        if ($TokenResponse.ExpiredIn($ExpiresInMinutes)) {
            $Type = $TokenResponse.GetType()
            $lockWasTaken = $false
            [Monitor]::Enter($Type::_lock, [ref] $lockWasTaken)
            try {
                if ($TokenResponse.ExpiredIn($ExpiresInMinutes)) {
                    $params = $TokenResponse.RenewParams
                    $newToken = Get-OAuth2TokenFromCredential @Params
                    $TokenResponse.UpdateToken($newToken)
                }
            }
            finally {
                if ($lockWasTaken) { [Monitor]::Exit($Type::_lock) }
            }
        }
        return $TokenResponse.Header
    }
}

# Invoke-ParallelForEach
function Invoke-ParallelForEach {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $false, Position = 0)]
        [ScriptBlock]
        $ScriptBlock,

        [Parameter(Mandatory = $false, ValueFromPipeline = $true, Position = 1)]
        [PSObject]
        $InputObject,

        [Parameter(Mandatory = $false, ValueFromPipeline = $false, Position = 2)]
        $ThrottleLimit = 30
    )
    begin {
        try {
            [ParallelPowerShellRunner]::MAX_RUNSPACES = $ThrottleLimit
            $Runner = [ParallelPowerShellRunner]::new($PSCmdlet)
            $Runner.SetScript($ScriptBlock)
        }
        catch {
            throw
        }
    }
    process {
        try {
            $Runner.QueueInput($PSItem)
        }
        catch {
            $PSCmdlet.ThrowTerminatingError($PSItem)
        }
    }
    end {
        try {
            $Runner.ExecuteQueuedCommands()
        }
        catch {
            throw
        }
    }
}

# Invoke-ProvisionNewDevices
function Invoke-ProvisionNewDevices {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, Position = 0)]
        [Object]
        $Device
    )
    begin {
        Write-Debug "$($MyInvocation.MyCommand.Name)$($PSBoundParameters.Keys.ForEach({" -$($_):$($PSBoundParameters[$_] -join ',')"}) -join '')"
        $Devices = [Collections.Generic.List[PSCustomObject]]@()
        $Current = Invoke-TDMApiProvisionRequest -Summary
        $MaxAvailable = 500 - $Current.TotalDevices
        $BatchSize = 100
    }
    process {
        $Devices.Add($Device)
    }
    end {
        if ($Devices.Count -gt $MaxAvailable) {
            while ($Devices.Count -gt $MaxAvailable) {
                $null = $Devices.RemoveAt($Devices.Count - 1)
            }
            Write-Warning "Device Limit Reached, Processing $MaxAvailable and skipping remaining..."
        }
        $Batches = @{}
        $BatchCount = [Math]::Ceiling($Devices.Count / $BatchSize)
        $index = 0
        for ($i = 0; $i -lt $BatchCount; $i++) {
            $Batches[$i] = [Collections.Generic.List[PSCustomObject]]@()
            for ($j = 0; $j -lt $BatchSize -and $index -lt $Devices.Count; $j++, $index++) {
                $Batches[$i].Add($Devices[$index])
            }
        }
        $Provision = for ($i = 0; $i -lt $Batches.Count; $i++) {
            Write-Debug "$($Batches[$i] | ConvertTo-Json -Compress)"
            ##Generate post body for enrollment and generating activation code
            $Batches[$i] | New-ProvisionBody | Invoke-TDMApiProvisionRequest -Method Post -OutputType ([BulkCreateResponse])
        }
        ##Generate post body for generating enrollment code
        $Responses = $Provision.Responses.FindAll({ $args[0].StatusCode -eq 200 })
        foreach ($Response in $Provision.Responses.FindAll({ $args[0].StatusCode -ne 200 })) {
            $DevInput = $Devices[$Provision.Responses.IndexOf($Response)]
            $ID = $DevInput.MACAddress
            $Msg = "$ID Error: $($Response.StatusCode) => $($Response.ErrorCode) => $($Response.Errors -join ',')"
            Write-Warning "Device Provisioning Failed: $Msg"
        }
        if ($Responses.Count -eq 0) {
            Write-Warning "No devices were provisioned."
            return
        }
        $TeamsUnProvisionedDevices = $Responses.Where({ $true }).ForEach({
                $String = [JsonConvert]::SerializeObject($_.Response, [BaseClass]::SerializerSettings)
                [JsonConvert]::DeserializeObject($String, [TeamsUnProvisionedDevice])
            })

        $TeamsUnProvisionedDevices | New-TeamsDeviceProvisioningOneTimePassword
    }
}

# Invoke-SignInDevices
function Invoke-SignInDevices {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 0)]
        [PSCredential]
        $Credential,

        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 1)]
        [string]
        $Id,

        [Parameter(Mandatory = $false, ValueFromPipeline = $false, Position = 2)]
        $ThrottleLimit = 30
    )
    begin {
        $ModulePath = $MyInvocation.MyCommand.Module.Path
        Write-Debug $ModulePath
        $SignInScript = {
            [CmdletBinding()]
            param (
                [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 0)]
                [PSCredential]
                $Credential,

                [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 1)]
                [string]
                $Id
            )

            $CommandType = 'RemoteLogin'
            $Response = Invoke-TDMApiRequest -Method Post -Route "/api/v2/devices/$Id/commands" -Body @{ Command = $CommandType }
            $Status = $Response.commandStatus
            $CommandId = $Response.baseInfo.id
            while ($Status -notin @('Successful', 'Failed')) {
                Write-Verbose "${Status}: Waiting for $CommandType command to complete..."
                Start-Sleep -Seconds 10
                $Response = Invoke-TDMApiRequest -Route "/api/v2/devices/$Id/commands/$CommandId"
                $Status = $Response.commandStatus
            }
            if ($Status -eq 'Failed') {
                Write-Error -Message "$CommandType command failed for $Id" -TargetObject $Response
                return
            }
            $DeviceCode = $Response.commandResponse.remoteLoginCommandResponse.deviceCodeInfo
            Invoke-SignInRequest -Code $DeviceCode.userCode -Uri $DeviceCode.verificationUri -Credential $Credential
        }
        $null = $PSBoundParameters.Remove('ThrottleLimit')
        try {
            [ParallelPowerShellRunner]::MAX_RUNSPACES = $ThrottleLimit
            $Runner = [ParallelPowerShellRunner]::new($PSCmdlet)
            $Runner.SetScript($SignInScript)
        }
        catch {
            throw
        }
    }
    process {
        try {
            $Runner.QueueInput($PSBoundParameters)
        }
        catch {
            $PSCmdlet.ThrowTerminatingError($PSItem)
        }
    }
    end {
        try {
            $Runner.ExecuteQueuedCommands()
        }
        catch {
            throw
        }
    }
}

# Invoke-SignOutDevices
function Invoke-SignOutDevices {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, Position = 0)]
        [TeamsDevice]
        $Device,

        [Parameter(Mandatory = $false, ValueFromPipeline = $false, Position = 1)]
        $ThrottleLimit = 30,

        [switch]
        $Wait,

        [switch]
        $PassThru
    )
    begin {
        $ModulePath = $MyInvocation.MyCommand.Module.Path
        Write-Debug $ModulePath
        $SignInScript = {
            [CmdletBinding()]
            param (
                [Parameter(Mandatory = $true, ValueFromPipeline = $true, Position = 0)]
                [PSCustomObject]
                $Device,

                [switch]
                $Wait,

                [switch]
                $PassThru
            )
            $Id = $Device.BaseInfo.Id
            $CommandType = 'RemoteLogout'
            $Response = Invoke-TDMApiRequest -Method Post -Route "/api/v2/devices/$Id/commands" -Body @{ Command = $CommandType }
            $Status = $Response.commandStatus
            $CommandId = $Response.baseInfo.id
            while ($Wait -and $Status -notin @('Successful', 'Failed')) {
                Write-Verbose "${Status}: Waiting for $CommandType command to complete..."
                Start-Sleep -Seconds 10
                $Response = Invoke-TDMApiRequest -Route "/api/v2/devices/$Id/commands/$CommandId"
                $Status = $Response.commandStatus
            }
            if ($Status -eq 'Failed') {
                Write-Error -Message "$CommandType command failed for $Id" -TargetObject $Response
                return
            }
            if ($PassThru) {
                return $Device
            }
        }
        $null = $PSBoundParameters.Remove('ThrottleLimit')
        try {
            [ParallelPowerShellRunner]::MAX_RUNSPACES = $ThrottleLimit
            $Runner = [ParallelPowerShellRunner]::new($PSCmdlet)
            $Runner.SetScript($SignInScript)
        }
        catch {
            throw
        }
    }
    process {
        try {
            $Runner.QueueInput($PSBoundParameters)
        }
        catch {
            $PSCmdlet.ThrowTerminatingError($PSItem)
        }
    }
    end {
        try {
            $Runner.ExecuteQueuedCommands()
        }
        catch {
            throw
        }
    }
}

# Invoke-TDMApiProvisionRequest
function Invoke-TDMApiProvisionRequest {
    [CmdletBinding(DefaultParameterSetName = 'Body')]
    param (
        [Parameter(Mandatory = $false, ValueFromPipeline = $true, ParameterSetName = 'Body')]
        [object]
        $Body,

        [Net.Http.HttpMethod]
        $Method = [Net.Http.HttpMethod]::Get,

        [Collections.IDictionary]
        $Query,

        [Type]
        $OutputType,

        [Parameter(Mandatory = $false, ValueFromPipeline = $true, ParameterSetName = 'Summary')]
        [switch]
        $Summary
    )

    begin {
        $Endpoint = 'devices'
        if ($Summary) {
            $Endpoint = 'summary'
            $null = $PSBoundParameters.Remove('Summary')
        }
        Write-Debug "$($MyInvocation.MyCommand.Name)$($PSBoundParameters.Keys.ForEach({" -$($_):$($PSBoundParameters[$_] -join ',')"}) -join '')"
        try {
            $Command = $ExecutionContext.InvokeCommand.GetCommand('Invoke-TDMApiRequest', 'Function')
            $SteppablePipeline = { & $Command -Route "/api/v2/provision/${endpoint}" -AsArray @PSBoundParameters }.GetSteppablePipeline()
            $SteppablePipeline.Begin($PSCmdlet)
        }
        catch {
            throw
        }
    }

    process {
        try {
            $SteppablePipeline.Process($PSItem)
        }
        catch {
            $PSCmdlet.ThrowTerminatingError($PSItem)
        }
    }

    end {
        try {
            $SteppablePipeline.End()
        }
        catch {
            throw
        }
    }
}

# Invoke-TDMApiRequest
# using namespace System
# using namespace System.Diagnostics
# using namespace System.Collections

# using namespace System.Collections.Concurrent
# using namespace System.IO
# using namespace System.Linq
# using namespace System.Management.Automation
# using namespace System.Management.Automation.Language
# using namespace System.Management.Automation.Runspaces
# using namespace System.Threading

# using namespace System.Net.Http.Headers

function Wait-AsyncResult {
    [Alias('await')]
    [CmdletBinding()]
    param(
        [Parameter(ValueFromPipeline)]
        [psobject[]] $InputObject
    )
    begin {
        $tasksToAwait = $null
        $otherAsyncResults = $null
    }
    process {
        foreach ($awaitable in $InputObject) {
            if ($awaitable -is [Task]) {
                if ($null -eq $tasksToAwait) {
                    $tasksToAwait = [List[Task]]::new()
                }

                $tasksToAwait.Add($awaitable)
                continue
            }

            if ($null -eq $otherAsyncResults) {
                $otherAsyncResults = [List[IAsyncResult]]::new()
            }

            if ($awaitable -isnot [IAsyncResult]) {
                $exception = [PSArgumentException]::new(
                    'The specified value does not implement the interface "IAsyncResult".')

                $PSCmdlet.WriteError(
                    [ErrorRecord]::new(
                        <# exception:     #> $exception,
                        <# errorId:       #> 'InputNotAwaitable',
                        <# errorCategory: #> [ErrorCategory]::InvalidArgument,
                        <# targetObject:  #> $awaitable))
                continue
            }

            $otherAsyncResults.Add($awaitable)
        }
    }
    end {
        if ($null -ne $tasksToAwait) {
            $task = [Task]::WhenAll($tasksToAwait)
            while (-not $task.AsyncWaitHandle.WaitOne(200)) { }
            foreach ($singleTask in $tasksToAwait) {
                $singleTask.GetAwaiter().GetResult()
            }
        }

        foreach ($singleAwaitable in $otherAsyncResults) {
            while (-not $singleAwaitable.AsyncWaitHandle.WaitOne(200)) { }
        }
    }
}

function Invoke-TDMApiRequest {
    [CmdletBinding()]
    param (
        [string]
        $Route,

        [Parameter(Mandatory = $false, ValueFromPipeline = $true)]
        [object]
        $Body,

        [switch]
        $AsArray,

        [Net.Http.HttpMethod]
        $Method = [Net.Http.HttpMethod]::Get,

        [Collections.IDictionary]
        $Query,

        [int]
        $MaximumRetries = 5,

        [Type]
        $OutputType = $null
    )
    begin {
        Write-Debug "$($MyInvocation.MyCommand.Name)$($PSBoundParameters.Keys.ForEach({" -$($_):$($PSBoundParameters[$_] -join ',')"}) -join '')"
        Assert-TeamsDeviceManagementConnected
        if ($null -eq [ConnectionInfo]::Client) {
            $lockWasTaken = $false
            [Monitor]::Enter([ConnectionInfo]::_lock, [ref] $lockWasTaken)
            try {
                if ($null -eq [ConnectionInfo]::Client) {
                    if ($PSEdition -eq 'Desktop') {
                        $Handler = [HttpClientHandler]@{
                            AutomaticDecompression  = [DecompressionMethods]::None -bor [DecompressionMethods]::GZip -bor [DecompressionMethods]::Deflate
                            MaxConnectionsPerServer = 30
                        }
                    }
                    else {
                        $Handler = [SocketsHttpHandler]@{
                            AutomaticDecompression      = [DecompressionMethods]::All
                            MaxConnectionsPerServer     = 30
                            PooledConnectionIdleTimeout = [TimeSpan]::FromMinutes(2)
                            PooledConnectionLifetime    = [TimeSpan]::FromMinutes(10)
                        }
                    }
                    [ConnectionInfo]::Client = [HttpClient]::new($Handler)
                    [ConnectionInfo]::Client.BaseAddress = [Uri]::new("https://admin.devicemgmt.teams.microsoft.com/")
                    [ConnectionInfo]::Client.DefaultRequestHeaders.Authorization = [ConnectionInfo]::CurrentConnection | Get-OAuth2TokenHeader
                }
            }
            finally {
                if ($lockWasTaken) { [Monitor]::Exit([ConnectionInfo]::_lock) }
            }
        }
        $BodyObjects = [List[object]]::new()
        $BackoffTimeBase = Get-Random -Minimum 1.5 -Maximum 2.5
    }
    process {
        if ($AsArray -and $null -ne $Body) { $BodyObjects.Add($Body) }
    }
    end {
        if ($null -ne $Query -and $Query.Values.Where({ $null -ne $_ }, 'First', 1).Count -gt 0) {
            $Route += "?$($Query.Keys.Where({$null -ne $Query[$_]}).ForEach({"$_=$([Uri]::EscapeDataString($Query[$_]))"}) -join '&')"
        }
        $CTJParams = @{
            Compress = $true
            Depth    = 10
        }
        if ($BodyObjects.Count -gt 0) {
            $Body = $BodyObjects
        }
        $BodyString = if ($null -ne $Body) {
            if ($Body -is [BaseClass]) {
                [JsonConvert]::SerializeObject($Body, [BaseClass]::SerializerSettings)
            }
            elseif ($Body[0] -is [BaseClass]) {
                '[' + ($Body.Where({ $true }).ForEach({ [JsonConvert]::SerializeObject($_, [BaseClass]::SerializerSettings) }) -join ',') + ']'
            }
            else {
                ConvertTo-Json -InputObject $Body @CTJParams
            }
        }
        else {
            $null
        }
        $Retries = 0
        while ($Retries -lt $MaximumRetries) {
            [ConnectionInfo]::Client.DefaultRequestHeaders.Authorization = [ConnectionInfo]::CurrentConnection | Get-OAuth2TokenHeader
            $Request = [HttpRequestMessage]::new()
            $Request.RequestUri = [Uri]::new($Route, [UriKind]::Relative)
            $Request.Method = $Method
            Write-Verbose "Request [$Method] $([ConnectionInfo]::Client.BaseAddress.AbsoluteUri.TrimEnd('/'))$($Request.RequestUri)"
            if (![string]::IsNullOrEmpty($BodyString)) {
                $Request.Content = [StringContent]::new($BodyString, [Encoding]::UTF8)
                $Request.Content.Headers.ContentType = 'application/json'
                Write-Debug "RequestContent: $($BodyString)"
            }
            try {
                # $SendTask = [ConnectionInfo]::Client.SendAsync($Request)
                # $SendTask.Wait()
                # Write-Debug "ResponseCode: $($SendTask.Result.StatusCode)"
                # $Response = $SendTask.Result
                # $StringTask = $Response.EnsureSuccessStatusCode().Content.ReadAsStringAsync()
                # $StringTask.Wait()
                # $String = $StringTask.Result
                $Response = [ConnectionInfo]::Client.SendAsync($Request) | await
                Write-Debug "ResponseCode: $($Response.StatusCode)"
                $String = $Response.EnsureSuccessStatusCode().Content.ReadAsStringAsync() | await
                Write-Debug "ResponseContent: $String"
                if ($null -ne $OutputType) {
                    [JsonConvert]::DeserializeObject($String, $OutputType) | Write-Output
                }
                else {
                    $String | ConvertFrom-Json | Write-Output
                }
                return
            }
            catch {
                if ($null -eq $Response -or $Response.StatusCode -notin @(401, 408, 500, 502, 503, 504) -or $Retries -eq $MaximumRetries) {
                    if ($null -ne $Response) {
                        try {
                            # $StringTask = $Response.Content.ReadAsStringAsync()
                            # $StringTask.Wait()
                            # $String = $StringTask.Result
                            $String = $Response.Content.ReadAsStringAsync() | await
                            Write-Debug "ErrorResponseContent: $String"
                            $Object = $String | ConvertFrom-Json -ErrorAction Stop
                        }
                        catch {}
                        if ($null -ne $Object.value.errorMessage) {
                            throw $Object.value.errorMessage
                        }
                        if ($null -ne $Object.errorMessage) {
                            throw $Object.errorMessage
                        }
                        if ($null -ne $Object.error.Message) {
                            throw $Object.error.Message
                        }
                        if ($null -ne $Object.error) {
                            throw $Object.error
                        }
                    }
                    throw
                }
                $SleepSeconds = [Math]::Pow($BackoffTimeBase, $Retries)
                $Retries++
                Write-Verbose "Got $($Response.StatusCode) response, retrying in $($SleepSeconds.ToString('F2'))s"
                Write-Verbose "$($MaximumRetries - $Retries) more attempts remain"
                Start-Sleep -Seconds $SleepSeconds
            }
        }
    }
}

# New-ProvisionBody
function New-ProvisionBody {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 0)]
        [string]
        $MACAddress,

        [Parameter(Mandatory = $false, ValueFromPipelineByPropertyName = $true, Position = 1)]
        [string]
        $Location
    )
    begin {
        $key = 0
    }
    process {
        return [PSCustomObject]@{
            key              = ++$key
            uniqueIdRef      = @{
                uniqueId = ($MACAddress -replace '[^A-Z0-9]', '').ToUpper()
                type     = "MAC_ID"
            }
            assignedLocation = $Location
        }
    }
}

# Set-AccountPassword
function Set-AccountPassword {
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [PSCredential]
        $Credential
    )
    process {
        $IRMParams = @{
            Uri         = "https://graph.microsoft.com/v1.0/users/$($Credential.UserName)"
            Method      = 'Patch'
            ContentType = 'application/json'
            Headers     = @{
                Authorization = ([GraphConnectionInfo]::CurrentConnection | Get-OAuth2TokenHeader).ToString()
            }
            Verbose     = $false
            ErrorAction = 'Stop'
        }
        Write-Debug "$($MyInvocation.MyCommand.Name): $($IRMParams.Keys.ForEach({"${_}:$($IRMParams[$_])"}))"
        if ($PSCmdlet.ShouldProcess($Credential.UserName, 'Set Password')) {
            $IRMParams.Body = @{
                passwordProfile = @{
                    password                      = $Credential.GetNetworkCredential().Password
                    forceChangePasswordNextSignIn = $false
                }
            } | ConvertTo-Json
            $null = Invoke-RestMethod @IRMParams
        }
    }
}

# Add-TeamsDeviceCredential
function Add-TeamsDeviceCredential {
    [CmdletBinding()]
    [OutputType([TeamsDevice])]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [DecoratedTeamsDevice]
        $InputDevice,

        [Parameter(Mandatory = $true, Position = 0)]
        [Collections.IDictionary]
        $CredentialLookup,

        [Parameter(Mandatory = $false, Position = 1)]
        [string]
        $LookupKey = 'macAddressInfos.macAddress'
    )
    begin {
        $MACSeparators = @('', ':', '-')
        $Local:SharedAccountLookup = @{}
    }
    process {
        $AllKeys = [ScriptBlock]::Create("`$InputDevice.$LookupKey").InvokeReturnAsIs()
        if ($AllKeys.Count -lt 2) {
            $AllKeys = @($AllKeys)
        }
        $Lookup = $null
        $i = 0
        while ($null -eq $Lookup -and $i -lt $AllKeys.Count) {
            $Key = $AllKeys[$i]
            $Lookup = if (!$CredentialLookup.ContainsKey($Key)) {
                $KeyParts = ($Key -split '([0-9A-F]{2})').Where({ $_ -notin $MACSeparators })
                foreach ($Separator in $MACSeparators) {
                    if ($Key.IndexOf($Separator) -gt -1) { continue }
                    $NewKey = $KeyParts -join $Separator
                    if ($CredentialLookup.ContainsKey($NewKey)) {
                        $NewKey
                        break
                    }
                }
            }
            else {
                $Key
            }
            $i++
        }
        if ($null -eq $Lookup) {
            Write-Error "$($InputDevice.BaseInfo.Id) not found in CredentialLookup using key: $Key"
            return
        }
        $New = [DecoratedTeamsDevice]$InputDevice
        $Value = $CredentialLookup[$Lookup]
        if ($Value -is [PSCredential]) {
            $Local:SharedAccountLookup[$Value.UserName] = $Value
            $Value = $Value.UserName
        }
        elseif (!$Local:SharedAccountLookup.ContainsKey($Value)) {
            $Local:SharedAccountLookup[$Value] = [PSCredential]::new($Value, (New-Password))
            # password reset on graph endpoint here
            $Local:SharedAccountLookup[$Value] | Set-AccountPassword -ErrorAction Stop
        }
        $New.Credential = $Local:SharedAccountLookup[$Value]
        $New | Write-Output
    }
}

# Connect-TeamsDeviceManagement
function Connect-TeamsDeviceManagement {
    [CmdletBinding(DefaultParameterSetName = 'Credential')]
    param (
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $false, Position = 0, ParameterSetName = 'Credential')]
        [PSCredential]
        $Credential,

        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $false, Position = 0, ParameterSetName = 'CertificateThumbprint')]
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $false, Position = 0, ParameterSetName = 'Certificate')]
        [string]
        $UserName,

        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $false, Position = 1, ParameterSetName = 'CertificateThumbprint')]
        [string]
        $CertificateThumbprint,

        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $false, Position = 1, ParameterSetName = 'Certificate')]
        [Security.Cryptography.X509Certificates.X509Certificate2]
        $Certificate,

        [Parameter(Mandatory = $false)]
        [AllowEmptyString()]
        [string]
        $ClientId,

        [Parameter(Mandatory = $false)]
        [string]
        $RedirectUri,

        [Parameter(Mandatory = $false)]
        [string]
        $Tenant
    )
    begin {
        $GraphClientId = '14d82eec-204b-4c2f-b7e8-296a70dab67e'
        $DevManagementClientId = '12128f48-ec9e-42f0-b203-ea49fb6af367'
        if (![string]::IsNullOrEmpty($ClientId)) {
            $DevManagementClientId = $ClientId
            $GraphClientId = $ClientId
        }

        $GraphRedirectUri = 'https://login.microsoftonline.com/common/oauth2/nativeclient'
        $DevManagementRedirectUri = 'http://localhost'
        if (![string]::IsNullOrEmpty($RedirectUri)) {
            $DevManagementRedirectUri = $RedirectUri
            $GraphRedirectUri = $RedirectUri
        }
        Write-Debug "$($MyInvocation.MyCommand.Name)$($PSBoundParameters.Keys.ForEach({" -$($_):$($PSBoundParameters[$_] -join ',')"}) -join '')"

        $null = $PSBoundParameters.Remove('ClientId')
        $null = $PSBoundParameters.Remove('RedirectUri')
    }
    end {
        $GetTokenSplat = @{
            Scope       = [ConnectionInfo]::Scopes
            Type        = [ConnectionInfo]
            ClientId    = $DevManagementClientId
            RedirectUri = $DevManagementRedirectUri
        }
        if ($null -eq [ConnectionInfo]::CurrentConnection -or [ConnectionInfo]::CurrentConnection.RenewParams.Keys.Where({
                    $Param = [ConnectionInfo]::CurrentConnection.RenewParams[$_]
                    $NewParam = $GetTokenSplat[$_]
                    if ($null -eq $NewParam) { $NewParam = $PSBoundParameters[$_] }
                    $Param -ne $NewParam -or ($Param -is [PSCredential] -and $Param.UserName -ne $NewParam.UserName)
                }, 'First', 1).Count -gt 0) {
            [ConnectionInfo]::CurrentConnection = Get-OAuth2TokenFromCredential @GetTokenSplat @PSBoundParameters
        }
        if ($null -eq [ConnectionInfo]::CurrentConnection) {
            throw 'Failed to connect to Microsoft Teams Device Management'
        }
        # TODO: Make this optional, and figure out the needed scopes for graph and password reset
        $GetTokenSplat = @{
            Scope       = [GraphConnectionInfo]::Scopes
            Type        = [GraphConnectionInfo]
            ClientId    = $GraphClientId
            RedirectUri = $GraphRedirectUri
        }
        if ($null -eq [GraphConnectionInfo]::CurrentConnection -or [GraphConnectionInfo]::CurrentConnection.RenewParams.Keys.Where({
                    $Param = [ConnectionInfo]::CurrentConnection.RenewParams[$_]
                    $NewParam = $GetTokenSplat[$_]
                    if ($null -eq $NewParam) { $NewParam = $PSBoundParameters[$_] }
                    $Param -ne $NewParam -or ($Param -is [PSCredential] -and $Param.UserName -ne $NewParam.UserName)
                }, 'First', 1).Count -gt 0) {
            [GraphConnectionInfo]::CurrentConnection = Get-OAuth2TokenFromCredential @GetTokenSplat @PSBoundParameters
        }
        if ($null -eq [GraphConnectionInfo]::CurrentConnection) {
            throw 'Failed to connect to Microsoft Graph'
        }
    }
}

# Get-TeamsDevice
function Get-TeamsDevice {
    [CmdletBinding(DefaultParameterSetName = 'Query')]
    [OutputType([TeamsDevice])]
    param (
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 0, ParameterSetName = 'Id')]
        [string]
        $Id,

        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 0, ParameterSetName = 'BaseInfo')]
        [BaseInfo]
        $BaseInfo,

        [Parameter(Mandatory = $false, ParameterSetName = 'Query')]
        [bool]
        $FirstSignInDone,

        [Parameter(Mandatory = $false, ParameterSetName = 'Query')]
        [ValidateSet('SignedOut', 'SignedIn')]
        [string[]]
        $UserStatus,

        [Parameter(Mandatory = $false, ParameterSetName = 'Query')]
        [ValidateSet('Unknown', 'CommonArea', 'Conference', 'Personal')]
        [string[]]
        $UserType,

        [Parameter(Mandatory = $false, ParameterSetName = 'Query')]
        [ValidateSet('Unknown', 'Healthy', 'NonUrgent', 'Critical', 'Offline')]
        [string[]]
        $HealthState,

        [Parameter(Mandatory = $false, ParameterSetName = 'Query')]
        [ValidateSet('Unknown',
            'IpPhone',
            'TeamsRoom',
            'SurfaceHub',
            'CollaborationBar',
            'TeamsDisplay',
            'TouchConsole',
            'LowCostPhone',
            'TeamsPanel',
            'SIP',
            'SIPAnalog')]
        [string[]]
        $DeviceType,

        [Parameter(Mandatory = $false, ParameterSetName = 'Query')]
        [ValidateSet('AutoUpdateRing0', 'AutoUpdateRing1', 'AutoUpdateRing2')]
        [string[]]
        $AutoUpdateRing,

        [Parameter(Mandatory = $false, ValueFromPipelineByPropertyName, ParameterSetName = 'Query')]
        [string]
        $MACAddress
    )
    begin {
        $MACAddresses = [Collections.Generic.HashSet[string]]@()
    }
    process {
        if (![string]::IsNullOrEmpty($MACAddress)) {
            $MACAddress = $MACAddress | CleanMACAddress
            $null = $MACAddresses.Add($MACAddress)
        }
        if ($PSCmdlet.ParameterSetName -eq 'Query' -and $null -ne $Id) {
            return
        }
        $RequestParams = @{
            Route      = '/api/v2/devices'
            OutputType = [TeamsDevice]
        }
        if ($PSCmdlet.ParameterSetName -eq 'BaseInfo') {
            $RequestParams['Route'] += "/$($BaseInfo.Id)"
        }
        else {
            $RequestParams['Route'] += "/$Id"
        }
        Invoke-TDMApiRequest @RequestParams | Write-Output
    }
    end {
        if ($PSCmdlet.ParameterSetName -ne 'Query') {
            return
        }
        $FilterJson = @{}
        if ($PSBoundParameters.ContainsKey('FirstSignInDone')) {
            $FilterJson['firstSignInDone'] = $FirstSignInDone
        }
        if ($PSBoundParameters.ContainsKey('UserStatus')) {
            $FilterJson['userStatus'] = @{eq = $UserStatus }
        }
        if ($PSBoundParameters.ContainsKey('HealthState')) {
            $FilterJson['healthStates'] = @{eq = $HealthState }
        }
        if ($PSBoundParameters.ContainsKey('UserType')) {
            $FilterJson['newUserTypes'] = @{eq = $UserType }
        }
        if ($PSBoundParameters.ContainsKey('DeviceType')) {
            $FilterJson['deviceTypes'] = @{eq = $DeviceType }
        }
        if ($PSBoundParameters.ContainsKey('AutoUpdateRing')) {
            $FilterJson['autoUpdateRings'] = @{eq = $AutoUpdateRing }
        }
        $Query = @{
            'pageSize' = 500
        }
        if ($FilterJson.Keys.Count -gt 0) {
            $Query['filterJson'] = $FilterJson | ConvertTo-Json -Compress -Depth 5
        }
        $RequestParams = @{
            Route      = '/api/v2/devices'
            Query      = $Query
            OutputType = [TeamsDeviceResponse]
        }

        $DeviceResponse = Invoke-TDMApiRequest @RequestParams
        if ($MACAddresses.Count -gt 0) {
            $Copy = [string[]]$MACAddresses
            foreach ($mAddress in $Copy) {
                $Devices = $DeviceResponse.Devices.Where({
                        @($_.MacAddressInfos.MACAddress | CleanMACAddress).Where({
                                $_ -eq $mAddress }, 'First', 1).Count -gt 0 }, 'First', 1)
                if ($Devices.Count -gt 0) {
                    $Devices | Write-Output
                    $null = $MACAddresses.Remove($mAddress)
                }
            }
            if ($MACAddresses.Count -eq 0) {
                # We found all the devices, so we can
                return
            }
        }
        else {
            $DeviceResponse.Devices | Write-Output
        }
        while ($null -ne $DeviceResponse.ContinuationToken) {
            $RequestParams['Query']['continuationToken'] = $DeviceResponse.ContinuationToken
            $DeviceResponse = Invoke-TDMApiRequest @RequestParams
            if ($MACAddresses.Count -gt 0) {
                $Copy = [string[]]$MACAddresses
                foreach ($mAddress in $Copy) {
                    $Devices = $DeviceResponse.Devices.Where({
                            @($_.MacAddressInfos.MACAddress | CleanMACAddress).Where({
                                    $_ -eq $mAddress }, 'First', 1).Count -gt 0 }, 'First', 1)
                    if ($Devices.Count -gt 0) {
                        $Devices | Write-Output
                        $null = $MACAddresses.Remove($mAddress)
                    }
                }
                if ($MACAddresses.Count -eq 0) {
                    # We found all the devices, so we can
                    return
                }
                # No devices found, so let's
                continue
            }
            else {
                $DeviceResponse.Devices | Write-Output
            }
        }
    }
}

# Get-TeamsDeviceConfigurationProfile
function Get-TeamsDeviceConfigurationProfile {
    [CmdletBinding()]
    [OutputType([ConfigProfile])]
    param(
        [Parameter(Mandatory = $false)]
        [string[]]
        $ProfileName,

        [Parameter(Mandatory = $false)]
        [DeviceType[]]
        $DeviceType
    )
    process {
        # TODO: Update command to align to rest of module
        # TODO: Create Set-TeamsDeviceConfigurationProfile
        # TODO: Create New-TeamsDeviceTag
        # TODO: Create Get-TeamsDeviceTag
        # TODO: Create Set-TeamsDeviceTag
        # TODO: Create Grant-TeamsDeviceTag
        $FilterJson = @{}
        if ($PSBoundParameters.ContainsKey('DeviceType')) {
            $FilterJson['deviceTypes'] = @{eq = $DeviceType }
        }
        if ($PSBoundParameters.ContainsKey('ProfileName')) {
            $FilterJson['configProfileNames'] = @{eq = $ProfileName }
        }
        $Query = @{}
        if ($FilterJson.Keys.Count -gt 0) {
            $Query['filterJson'] = $FilterJson | ConvertTo-Json -Compress -Depth 5
        }
        $TDMParams = @{
            Route      = '/api/v2/configProfiles'
            OutputType = [ConfigProfileResponse]
            Query      = $Query
        }
        $ConfigProfileResponse = Invoke-TDMApiRequest @TDMParams
        $ConfigProfileResponse.PaginatedConfigProfiles | Where-Object {
            (!$PSBoundParameters.ContainsKey('DeviceType') -or
            $_.DeviceType -in $DeviceType) -and
            (!$PSBoundParameters.ContainsKey('ProfileName') -or
            $_.Identity -in $ProfileName)
        } | Write-Output
        while (![string]::IsNullOrEmpty($ConfigProfileResponse.ContinuationToken)) {
            $TDMParams['Query']['ContinuationToken'] = $ConfigProfileResponse.ContinuationToken
            $ConfigProfileResponse = Invoke-TDMApiRequest @TDMParams
            $ConfigProfileResponse.PaginatedConfigProfiles | Where-Object {
                (!$PSBoundParameters.ContainsKey('DeviceType') -or
                $_.DeviceType -in $DeviceType) -and
                (!$PSBoundParameters.ContainsKey('ProfileName') -or
                $_.Identity -in $ProfileName)
            } | Write-Output
        }
    }
}

<#
CreateConfigProfileRequest
[FromBody]
public ConfigProfileResource ConfigProfile { get; set; }
#>

# Get-TeamsDeviceProvisionRequest
function Get-TeamsDeviceProvisionRequest {
    [CmdletBinding()]
    [OutputType([TeamsUnProvisionedDevice])]
    param (
        [int]
        $PageSize = 50
    )
    end {
        $Response = Invoke-TDMApiProvisionRequest -Method Get -Query @{ limit = $PageSize }
        $Response.Items.ForEach({
                $S = $_ | ConvertTo-Json -Compress -Depth 10
                [JsonConvert]::DeserializeObject($S, [TeamsUnProvisionedDevice])
            }) | Write-Output
        while (![string]::IsNullOrEmpty($Response.ContinuationToken)) {
            $Response = Invoke-TDMApiProvisionRequest -Method Get -Query @{ limit = $PageSize; continuationToken = $Response.ContinuationToken }
            $Response.Items.ForEach({
                    $S = $_ | ConvertTo-Json -Compress -Depth 10
                    [JsonConvert]::DeserializeObject($S, [TeamsUnProvisionedDevice])
                }) | Write-Output
        }
    }
}

# Grant-TeamsDeviceConfigurationProfile
function Grant-TeamsDeviceConfigurationProfile {
    [CmdletBinding(DefaultParameterSetName = 'Name', SupportsShouldProcess, ConfirmImpact = 'Low')]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [TeamsDevice]
        $Device,

        [Parameter(Mandatory, Position = 0, ParameterSetName = 'Profile')]
        [ConfigProfile]
        $ConfigurationProfile,

        [Parameter(Mandatory, Position = 0, ParameterSetName = 'Name')]
        [string]
        $ProfileName
    )
    begin {
        if ($PSBoundParameters.ContainsKey('ProfileName')) {
            $Profiles = @(Get-TeamsDeviceConfigurationProfile -ProfileName $ProfileName)
            if ($Profiles.Count -eq 0) {
                Write-Error "$Name not found in existing profiles!"
                return
            }
            $Name = $ProfileName
        }
        else {
            $Profiles = @($ConfigurationProfile)
            $Name = $ConfigurationProfile.Identity
        }
        $ConfigHash = @{}
        foreach ($profile in $Profiles) {
            if ($ConfigHash.ContainsKey($profile.DeviceType)) {
                Write-Error "Multiple versions of $Name exist!"
                return
            }
            $ConfigHash[$profile.DeviceType] = $profile.BaseInfo.Id
        }
        $Payload = [List[PSCustomObject]]::new()
    }
    process {
        if (!$ConfigHash.ContainsKey($Device.DeviceType)) {
            Write-Error "$($Device.DeviceType) not found in existing profiles!"
            return
        }
        if ($Device.ProvisionInfo.FirstSignInDone -eq $false) {
            Write-Error "$($Device.BaseInfo.Id) has not yet signed in!"
            return
        }
        if ($PSCmdlet.ShouldProcess($Device.BaseInfo.Id)) {
            $Payload.Add(@{
                    'device-id' = $Device.BaseInfo.Id
                    Commands    = @(@{
                            cmd            = 'ConfigUpdate'
                            payloadId      = $ConfigHash[$Device.DeviceType]
                            runAtTimeStamp = $null
                        })
                })
        }
    }
    end {
        if ($Payload.Count -gt 0) {
            Invoke-TDMApiRequest -Route '/admin/api/v1/devices/commands' -Body $Payload -Method Post
        }
    }
}

# New-TeamsDeviceConfigurationProfile
function New-TeamsDeviceConfigurationProfile {
    [CmdletBinding()]
    [OutputType([ConfigProfile])]
    param(
        [ValidateLength(0, 256)]
        [Parameter(Mandatory)]
        [string]
        $ProfileName,

        [Parameter(Mandatory)]
        [DeviceType]
        $DeviceType,

        [ValidateLength(0, 1024)]
        [string]
        $Description,

        [int]
        $ConfigProfileCreationType,

        [bool]
        $DeviceLock,

        [ValidateRange(30, 3600)]
        [int]
        $DeviceLockTimeout,

        [string]
        $DeviceLockPin,

        [string]
        $Language = 'EN-US',

        [string]
        $TimeZone = '-12:00',

        [string]
        $TimeZoneId = 'DatelineStandardTime',

        [ValidateRange(0, 2)]
        [int]
        $TimeDst,

        [ValidateSet('DD/MM/YYYY', 'YYYY/MM/DD')]
        [string]
        $DateFormat = 'DD/MM/YYYY',

        [ValidateSet('12', '24')]
        [string]
        $TimeFormat = '12',

        [bool]
        $DisplayScreenSaver,

        [ValidateRange(30, 3600)]
        [int]
        $ScreenSaverTimeout = 900,

        [ValidateRange(0, 100)]
        [int]
        $DisplayBacklitBrightness = 80,

        [ValidateRange(30, 3600)]
        [int]
        $DisplayBacklitTimeout = 900,

        [bool]
        $DisplayHighContrast,

        [bool]
        $SilentMode,

        [string]
        $OfficeStartHours,

        [string]
        $OfficeEndHours,

        [bool]
        $PowerSaving,

        [bool]
        $LoggingEnabled,

        [string]
        $LoggingTypes,

        [string]
        $NetworkDhcp,

        [bool]
        $NetworkPcPort,

        [string]
        $DeviceDefaultAdminPassword,

        [bool]
        $ScreenCapture,

        [int]
        $AssignedTo,

        [bool]
        $LANPort,

        [bool]
        $DHCPEnabled,

        [string]
        $HostName,

        [string]
        $DomainName,

        [string]
        $IPAddress,

        [string]
        $SubnetMask,

        [string]
        $DefaultGateway,

        [string]
        $PrimaryDNS,

        [string]
        $SecondaryDNS,

        [bool]
        $HideMeetingNames,

        [bool]
        $UsageStateIndicator,

        [bool]
        $CheckinNotification,

        [bool]
        $RoomCapacityNotificationEnabled,

        [bool]
        $IsIPPhonePremiumCapSkuEnabled,

        [bool]
        $IsRoomEquipmentEnabled,

        [bool]
        $BluetoothBeconingEnabled,

        [bool]
        $BYOMAutoAcceptEnabled,

        [bool]
        $AllowRoomRemoteEnabled,

        [string]
        $UsageStateIndicatorBusyStateColorName,

        [int]
        $UsageStateIndicatorBusyStateColorR,

        [int]
        $UsageStateIndicatorBusyStateColorG,

        [int]
        $UsageStateIndicatorBusyStateColorB,

        [bool]
        $CheckinRoomReleaseEnabled,

        [int]
        $CheckinRoomReleaseTimeout,

        [string]
        $Theme,

        [bool]
        $IsDeviceAppRestartEnabled,

        [bool]
        $IsDeviceAppAutoRestartEnabled,

        [int]
        $ScheduledDeviceAppRestartTime,

        [switch]
        $PassThru
    )
    end {
        $Existing = Get-TeamsDeviceConfigurationProfile -ProfileName $ProfileName -DeviceType $DeviceType
        if ($null -ne $Existing) {
            Write-Warning "A configuration named $ProfileName for $DeviceType already exists"
            return
        }
        $Command = $PSCmdlet.InvokeCommand.GetCommand('New-TeamsDeviceConfigurationProfile', 'Function')
        $ParameterNames = $Command.Parameters.Keys
        $ConfigProfile = [ConfigProfile]::new()
        $ConfigProfile.Identity = $ProfileName
        foreach ($Param in $ParameterNames) {
            if ($Param -in @('ProfileName', 'PassThru', 'Verbose', 'Debug', 'ErrorAction', 'WarningAction', 'InformationAction', 'ErrorVariable', 'WarningVariable', 'InformationVariable', 'OutVariable', 'OutBuffer', 'PipelineVariable')) {
                continue
            }
            try { $Value = Get-Variable -Name $Param -ValueOnly -ErrorAction Stop } catch { $Error.RemoveAt(0) }
            if ($null -eq $Value -or [string]::IsNullOrEmpty($Value)) { continue }
            if ($Value -is [ValueType] -and (($Value -is [bool] -and $Value -eq $false) -or $Value -eq 0) -and !$PSBoundParameters.ContainsKey($Param)) { continue }
            Write-Debug "$Param will be set to ($Value)"
            if ($Param -in @('IsDeviceAppRestartEnabled', 'IsDeviceAppAutoRestartEnabled', 'ScheduledDeviceAppRestartTime')) {
                if ($null -eq $ConfigProfile.DeviceAppRestartConfig) {
                    $ConfigProfile.DeviceAppRestartConfig = [DeviceAppRestartConfig]::new()
                }
                $ConfigProfile.DeviceAppRestartConfig.$Param = $Value
                continue
            }
            if ($Param -eq 'Theme') {
                if ($null -eq $ConfigProfile.Theme) {
                    $ConfigProfile.Theme = [Theme]::new()
                }
                $ConfigProfile.Theme.Name = $Value
                continue
            }
            if ($Param.StartsWith('CheckinRoomRelease')) {
                if ($null -eq $ConfigProfile.CheckinRoomReleaseConfig) {
                    $ConfigProfile.CheckinRoomReleaseConfig = [CheckinRoomReleaseConfig]::new()
                }
                $ConfigProfile.CheckinRoomReleaseConfig."$($Param -replace '^CheckinRoomRelease','')" = $Value
                continue
            }
            if ($Param.StartsWith('UsageStateIndicatorBusyStateColor')) {
                if ($null -eq $ConfigProfile.UsageStateIndicatorBusyStateColor) {
                    $ConfigProfile.UsageStateIndicatorBusyStateColor = [Color]::new()
                }
                $ConfigProfile.UsageStateIndicatorBusyStateColor."$($Param -replace '^UsageStateIndicatorBusyStateColor','')" = $Value
                continue
            }
            $ConfigProfile.$Param = $Value
        }
        $TDMParams = @{
            Route      = '/api/v2/configProfiles'
            Method     = 'Post'
            Body       = $ConfigProfile
            OutputType = [ConfigProfile]
        }
        $ConfigProfileResponse = Invoke-TDMApiRequest @TDMParams
        if ($PassThru) {
            $ConfigProfileResponse | Write-Output
        }
    }
}

# New-TeamsDeviceCredentialLookup
function New-TeamsDeviceCredentialLookup {
    # Make the Credential Lookup another function that returns the lookup, taking the id and username and/or password and returning the cleaned hash
    [CmdletBinding(DefaultParameterSetName = 'Username')]
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [string]
        $MACAddress,

        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [string]
        $UserName,

        [Parameter(Mandatory, ValueFromPipelineByPropertyName, ParameterSetName = 'Credential')]
        [SecureString]
        $Password
    )
    begin {
        $Lookup = @{}
    }
    process {
        $Lookup[$MACAddress] = $UserName
        if ($PSCmdlet.ParameterSetName -eq 'Credential') {
            $Lookup[$MACAddress] = [PSCredential]::new($UserName, $Password)
        }
    }
    end {
        $Lookup
    }
}

# New-TeamsDeviceProvisioningOneTimePassword
function New-TeamsDeviceProvisioningOneTimePassword {
    [CmdletBinding()]
    [OutputType([EnrollmentData])]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName, Position = 0)]
        [TeamsUnProvisionedDevice]
        $Device
    )
    begin {
        $BaseInfoCollection = [Collections.Generic.List[TeamsUnProvisionedDevice]]@()
    }
    process {
        $Device.LastOperationType = [ProvisioningOperationType]::GENERATE_ENROLLMENT
        $Device.Enrollment = $null
        $BaseInfoCollection.Add($Device)
    }
    end {
        $TDMParams = @{
            Method     = 'Patch'
            Query      = @{
                uniquePerDevice  = $false
                enrollmentMethod = [ProvisionMethod]::OTP
            }
            OutputType = [BulkResponse]
        }

        $EnrollmentResponse = $BaseInfoCollection | Invoke-TDMApiProvisionRequest @TDMParams
        $Success = $EnrollmentResponse.Responses.Values.Where({ $_.StatusCode -eq 200 })
        $Failures = $EnrollmentResponse.Responses.Values.Where({ $_.StatusCode -ne 200 })
        if ($Failures.Count -gt 0) {
            $Failures | ForEach-Object {
                Write-Warning "Device Provisioning Failed: $($_.ErrorCode) => $($_.Errors -join ',')"
            }
        }
        if ($Success.Count -eq 0) {
            return
        }
        $DeviceResult = [JsonConvert]::SerializeObject($Success[0].Response, [BaseClass]::SerializerSettings)
        if ($null -ne $DeviceResult) {
            $Device = [JsonConvert]::DeserializeObject($DeviceResult, [TeamsUnProvisionedDevice])
            $EnrollmentMethodData = $Device.Enrollment.EnrollmentMethodData

            return $EnrollmentMethodData
        }
    }
}

# New-TeamsDeviceProvisionRequest
function New-TeamsDeviceProvisionRequest {
    [CmdletBinding()]
    [OutputType([void])]
    param(
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 1)]
        [ValidatePattern('^(?=..([-:]?))([0-F]{2}($|\1)){6}$')]
        [string]
        $MACAddress,

        [Parameter(Mandatory = $false, ValueFromPipelineByPropertyName = $true, Position = 2)]
        [string]
        $Location
    )
    begin {
        $Devices = [Collections.Generic.List[PSCustomObject]]@()
    }
    process {
        Write-Debug "$MACAddress $Location"
        $Devices.Add([PSCustomObject]@{
                MACAddress = $MACAddress
                Location   = $Location
            })
        Write-Debug $Devices.Count
    }
    end {
        Write-Debug "$($Devices | ConvertTo-Json -Compress)"
        $provisionResult = $Devices | Invoke-ProvisionNewDevices
        return $provisionResult
    }
}

# New-TeamsDeviceSignInRequest
function New-TeamsDeviceSignInRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 0)]
        [Alias('DeviceCredential')]
        [PSCredential]
        $Credential,

        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 1)]
        [BaseInfo]
        $BaseInfo
    )
    begin {
        $Devices = [Collections.Generic.List[PSCustomObject]]::new()
    }
    process {
        $Devices.Add([PSCustomObject]@{
                Id         = $BaseInfo.Id
                Credential = $Credential
            })
    }
    end {
        $Devices | Invoke-SignInDevices | Write-Output
    }
}

# New-TeamsDeviceSignOutRequest
function New-TeamsDeviceSignOutRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, Position = 1)]
        [TeamsDevice]
        $Device,

        [switch]
        $Wait,

        [switch]
        $PassThru
    )
    begin {
        $Devices = [Collections.Generic.List[TeamsDevice]]::new()
        $SignOutParams = @{
            Wait     = $Wait
            PassThru = $PassThru
        }
    }
    process {
        if ($null -eq $Device.User.UserId) {
            if ($PassThru) {
                $Device | Write-Output
            }
            return
        }
        $Devices.Add($Device)
    }
    end {
        $Devices | Invoke-SignOutDevices @SignOutParams | Write-Output
    }
}

# Remove-TeamsDevice
function Remove-TeamsDevice {
    [CmdletBinding(DefaultParameterSetName = 'Device', SupportsShouldProcess, ConfirmImpact = 'High')]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ParameterSetName = 'Id')]
        [string]
        $Identity,

        [Parameter(Mandatory, ValueFromPipeline, ParameterSetName = 'Device')]
        [TeamsDevice]
        $Device
    )
    begin {
        $Payload = [PSCustomObject]@{
            deviceIds = [List[string]]::new()
        }
    }
    process {
        if ($Device) {
            $Payload.deviceIds.Add($Device.BaseInfo.Id)
        }
        else {
            $Payload.deviceIds.Add($Identity)
        }
        if ($PSCmdlet.ShouldProcess("$($Payload.deviceIds -join ',')", "Remove-TeamsDevice")) {
            $null = Invoke-TDMApiRequest -Route "/admin/api/v1/device-details/remove" -Method Post -Body $Payload
        }
        $Payload.deviceIds.Clear()
    }
}

# Remove-TeamsDeviceConfigurationProfile
function Remove-TeamsDeviceConfigurationProfile {
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
    [OutputType([ConfigProfile])]
    param(
        [Parameter(Mandatory)]
        [string]
        $ProfileName,

        [DeviceType]
        $DeviceType
    )
    end {
        $Params = @{
            ProfileName = $ProfileName
        }
        if ($PSBoundParameters.ContainsKey('DeviceType')) {
            $Params['DeviceType'] = $DeviceType
        }
        $Existing = Get-TeamsDeviceConfigurationProfile @Params
        if ($null -eq $Existing -or $Existing.Count -eq 0) {
            Write-Warning "A configuration named $ProfileName for $DeviceType does not exist"
            return
        }
        foreach ($Profile in $Existing) {
            $ID = $Profile.BaseInfo.Id
            if ($PSCmdlet.ShouldProcess("$($Profile.Identity) - $($Profile.DeviceType) [$ID]", "Remove-TeamsDeviceConfigurationProfile")) {
                $TDMParams = @{
                    Route       = "/api/v2/configProfiles/$ID"
                    Method      = 'Delete'
                    ErrorAction = 'Stop'
                }
                try {
                    $null = Invoke-TDMApiRequest @TDMParams
                }
                catch {
                    Write-Error $_
                    continue
                }
            }
        }
    }
}

# Remove-TeamsDeviceProvisionRequest
function Remove-TeamsDeviceProvisionRequest {
    [CmdletBinding(DefaultParameterSetName = 'BaseInfo', SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 0, ParameterSetName = 'Id')]
        [string]
        $Id,

        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, Position = 0, ParameterSetName = 'BaseInfo')]
        [BaseInfo]
        $BaseInfo
    )
    begin {
        $Devices = [Collections.Generic.List[object]]::new()
    }
    process {
        if ($PSCmdlet.ShouldProcess("$(if($null -ne $BaseInfo){$BaseInfo.Id}else{$Id})", "Remove-TeamsDeviceProvisionRequest")) {
            if ($null -ne $BaseInfo) {
                $Devices.Add($BaseInfo)
                return
            }
            $Devices.Add([PSCustomObject]@{
                    Id = $Id
                })
        }
    }
    end {
        $Devices | Invoke-TDMApiProvisionRequest -Method Delete
    }
}

$PSModule = $ExecutionContext.SessionState.Module
$PSModule.OnRemove = {
    [ParallelPowerShellRunner]::Clear([ParallelPowerShellRunner])
    [ParallelPowerShellRunner]::Clear([ParallelCmdletRunner])
}
