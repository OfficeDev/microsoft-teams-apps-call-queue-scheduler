using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Interact with query parameters or the body of the request.
$name = $Request.Query.Name
if (-not $name) {
    $name = $Request.Body.Name
}

$body = "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."

if ($name) {
    $body = "Hello, $name. This HTTP triggered function executed successfully."
}


# TBD: Add RG name and storage name to app settings
$StorageAccount = Get-AzStorageAccount -ResourceGroupName $ENV:ResourceGroupName -Name $ENV:StorageName
$ctx = $StorageAccount.Context

#Get-AzStorageTable –Context $ctx | select Name
$tableName = $ENV:DevicesTableName
$storageTable = Get-AzStorageTable –Name $tableName –Context $ctx
$cloudTable = $storageTable.CloudTable

#$body = Get-CsCallQueue | Select Name, Identity, Agents | ConvertTo-Json
#$body = Get-AzTableRow -table $cloudTable | ConvertTo-Json
$body = Get-AzTableRow -table $cloudTable
$body = if($body.length -eq 1) { ConvertTo-Json -InputObject @($body) } else { $body | ConvertTo-Json }


# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $body
})
