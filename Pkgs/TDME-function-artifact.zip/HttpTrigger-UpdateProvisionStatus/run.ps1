using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Interact with query parameters or the body of the request.
$name = $Request.Query.Name
if (-not $name) {
    $name = $Request.Body.Name
}

$csvDevices = $Request.Body.CsvDeviceList
Write-Host $csvDevices
If($csvDevices)
{

    # TBD: Add RG name and storage name to app settings
    $StorageAccount = Get-AzStorageAccount -ResourceGroupName $ENV:ResourceGroupName -Name $ENV:StorageName
    $ctx = $StorageAccount.Context

    #Get-AzStorageTable –Context $ctx | select Name
    $tableName = $ENV:DevicesTableName
    $storageTable = Get-AzStorageTable –Name $tableName –Context $ctx
    $cloudTable = $storageTable.CloudTable

    $devices = $csvDevices | ConvertFrom-Csv -Delimiter ','
    $devices | %{ 
            Write-Host "UPDATE ROW"
            Write-Host $_.MacAddress, $_.'ID Type', $_.Location, $_.Description, $_.RowKey
            $device = Get-AzTableRow -table $cloudTable -customFilter "(RowKey eq '$($_.RowKey)')"
            $device.ProvisionStatus = "Complete"
            $device | Update-AzTableRow -table $cloudTable
    }

}


# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $body
})
