using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Interact with query parameters or the body of the request.
$name = $Request.Query.Name
if (-not $name) {
    $name = $Request.Body.Name
}

$csvDevices = $Request.Body.CsvDeviceList
Write-Host $csvDevices
If($csvDevices)
{
    $Devices = $csvDevices | ConvertFrom-Csv -Delimiter ','
    Write-Host $Devices

    # TODO: Invoke TDME script here to get OTP for the devices
    $TDMExtensions = ".\Modules\TeamsDeviceManagementExtensions"
    Import-Module $TDMExtensions

    $TDMESvcAccountId  = $ENV:TDMESvcAccntUserId 
    $TDMESvcAccountPwd = $ENV:TDMESvcAccntUserPwd 
    $secpasswd = ConvertTo-SecureString -String $TDMESvcAccountPwd -AsPlainText -Force 
    $mycreds = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $TDMESvcAccountId, $secpasswd
    Connect-TeamsDeviceManagement -Credential $mycreds #-verbose -debug
    $expirationStr = (Get-Date).AddDays(1).ToString()
    Write-Host "Connected to TDME"
    <#
    $Script:MACSeparators = [Collections.Generic.HashSet[string]]@('-', ':', '.') 
    $Script:MACRegex = [Regex]::new('([0-9A-F]{2})', [Text.RegularExpressions.RegexOptions]::IgnoreCase) 
    filter CleanMACAddress { ($Script:MACRegex.Split($_).Where({ $_ -notin $Script:MACSeparators }) -join '').ToLower() } 
    $Pending = Get-TeamsDeviceProvisionRequest 
    $DevicesMAC = [Collections.Generic.HashSet[string]][string[]]($Devices.MACAddress | CleanMACAddress)
    $AlreadyPending = [Collections.Generic.HashSet[string]][string[]]($Pending.UniqueId.UniqueId | CleanMACAddress)
    $NeedProvisioning = $Devices.Where({ !$AlreadyPending.Contains(($_.MACAddress | CleanMACAddress)) })
    If($NeedProvisioning) { $NeedProvisioning | New-TeamsDeviceProvisionRequest }
    $NowPending = Get-TeamsDeviceProvisionRequest | Where-Object { $DevicesMAC.Contains(($_.UniqueId.UniqueId | CleanMACAddress)) }
    $otpInfo = $NowPending | New-TeamsDeviceProvisioningOneTimePassword
    #$otpInfo = $csvObj | New-TeamsDeviceProvisionRequest
    $otpInfo | select * | FT
    #>
    try
    {
        $Script:MACSeparators = [Collections.Generic.HashSet[string]]@('-', ':', '.') 
        $Script:MACRegex = [Regex]::new('([0-9A-F]{2})', [Text.RegularExpressions.RegexOptions]::IgnoreCase)
        filter CleanMACAddress { ($Script:MACRegex.Split($_).Where({ $_ -notin $Script:MACSeparators }) -join '').ToLower() }
        $Data = @{}
        $Devices | %{ $Data[$_.MacAddress] = $_.UPN }
        $PendingDevices = Get-TeamsDevice -FirstSignInDone $False
        $RequestedDevicesMAC = [Collections.Generic.HashSet[string]][string[]]($Devices.MACAddress | CleanMACAddress)
        $PendingDevices | ?{$_.DeviceIds.UniqueId -in $RequestedDevicesMAC} | Add-TeamsDeviceCredential -CredentialLookup $Data | New-TeamsDeviceSignInRequest
    }
    catch
    {
        Write-Host "Failed to remote signin the device. Error:" $_.Exception.Message
        return
    }
    # TBD: Add RG name and storage name to app settings
    $StorageAccount = Get-AzStorageAccount -ResourceGroupName 'tdme-rg' -Name 'tdmestorage'
    $ctx = $StorageAccount.Context

    #Get-AzStorageTable –Context $ctx | select Name
    $tableName = "DevicesInfo"
    $storageTable = Get-AzStorageTable –Name $tableName –Context $ctx
    $cloudTable = $storageTable.CloudTable

    $Devices | %{ 
            Write-Host "UPDATE ROW"
            Write-Host $_.MacAddress, $_.'ID Type', $_.Location, $_.Description, $_.RowKey
            $device = Get-AzTableRow -table $cloudTable -customFilter "(RowKey eq '$($_.RowKey)')"
            $device.RemoteSignStatus = "Complete"
            $device | Update-AzTableRow -table $cloudTable
    }

}


# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $body
})
